package bddSdet36L1.genericUtility;

public class PropertyFile {

}
