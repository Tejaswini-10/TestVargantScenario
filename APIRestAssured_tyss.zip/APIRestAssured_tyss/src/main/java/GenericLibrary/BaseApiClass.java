package GenericLibrary;

import org.testng.Reporter;
import org.testng.annotations.BeforeSuite;

public class BaseApiClass {
	
	DataBaseLibrary dataBaseLibrary=new DataBaseLibrary();
	JavaLibrary javaLibrary=new JavaLibrary();
	RestAssuredLibrary restAssuredLibrary =new RestAssuredLibrary();
	
@BeforeSuite
	public void bsConfig()
	{
		dataBaseLibrary.connectToDB();
		Reporter.log("...connection closed",true);
		baseURI="http://localhost";
		port=8084;
	}
@AfterSuite
{
		con.close();
	Reporter.log("...connection closed...",true);
}
	}


