package GenericLibrary;
/**
 * this interfacecontains all the endpoints
 * @author Tejaswini
 *
 */

public interface EndpointsLibrary {
	String createProject="/addProject";
	String	updateProject="/projects";
	String getAllProject="/projects";
	String 	getSingleProject="/projects";
	String	deleteProject="/projects";

}
