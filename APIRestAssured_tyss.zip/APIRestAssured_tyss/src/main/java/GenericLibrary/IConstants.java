package GenericLibrary;

public class IConstants {
	static String dbURL ="jdbc:mysql://localhost:3306/projects";
     String dbUserName="root";
	String dbpassword="root";
	String appUserName="rmgyantra";
	String appPassword="rmgy@9999";
			

}
