package GenericLibrary;

/**
 * this class contains testassured specific re usable methods
 * @author C.Tejaswini
 *
 */

public class RestAssuredLibrary { 
	/**
	 * this method will get the json data through jason path from response body
	 * @param resp
	 * @param path
	 * @return
	 */
	public String getJsonData(Response response,String path) 
	{
		String jsonData=response.jsonPath().get(path);
		return jsonData;
	}

}
