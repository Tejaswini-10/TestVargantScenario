package GenericLibrary;

import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DataBaseLibrary {
	
	Driver driverRef;
	Connection con;
	
	/**
	 * This method will establish the connection with mysql db
	 * @throws SQLException 
	 */
public void connectToDB() throws SQLException {
	driverRef = new Driver();
	DriverManager.registerDriver(driverRef);
	con=DriverManager.getConnection(IConstants.dbURL,IConstants.dbUserName,IConstants.dbpassword);
}
/**
 * This method is used foe the db connection
 * @throws SQException
 */
public void closeDB() {
	con.close();
	}
/**
 * This method is will execute the query and return the value only if the validation is succesful
 * @param query
 * @paramcloumnIndex
 * @param expData
 * @return
 * @throws SQLException
 */
public String readDataFromDBAjdValidate(String query,int columnIndex,String expData) {
	boolean flag=false;
	ResultSet result=con.createStatement().execute(query);
	While(result.next())
	{
		if(result.getString(columnIndex).equalsIgnoreCase(expData))
		{
			flag=true;
			break;
		}
	}
	if(flag) {
		System.out.println("data verified");
	}
	return expData;
}
else
{
	System.out.println("data not verified");
	return ;
}	
}
