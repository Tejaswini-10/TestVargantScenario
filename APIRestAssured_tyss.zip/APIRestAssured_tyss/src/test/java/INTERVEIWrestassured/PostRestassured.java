package INTERVEIWrestassured;

public class PostRestassured {

}
