package CRUDwithBDD;

import org.testng.annotations.Test;

import static io.restassured.RestAssured.*;


public class ReadGetAllProject {
	@Test
	public void getalltest() {

		baseURI = "http://localhost";
		port = 8084;

		when()
		.get("/projects")
		.then()
		.log().all();	
	}







}
