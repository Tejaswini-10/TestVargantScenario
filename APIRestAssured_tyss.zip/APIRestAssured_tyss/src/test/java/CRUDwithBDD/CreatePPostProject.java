package CRUDwithBDD;

import org.json.simple.JSONObject;
import org.testng.annotations.Test;

import GenericLibrary.JavaLibrary;
import io.restassured.http.ContentType;

import static io.restassured.RestAssured.*;

public class CreatePPostProject {
	@Test
	public void createtest() {
		//precondition
		JavaLibrary jlib=new JavaLibrary();

		JSONObject jobj=new JSONObject();

		jobj.put("createdBy", "tejaswini");
		jobj.put("projectName","Xylem"+jlib.getRandom());
		jobj.put("status","Completed");
		jobj.put("teamSize", 12);
		
		baseURI ="http://localhost";
		port = 8084;
		
		given()
		 .body(jobj)
		 .contentType(ContentType.JSON)
		
		.when()  //Step 2: perform action
		 .post("/addProject")
		 
		.then()  //Step 3: Validation
		 .assertThat()
		 .statusCode(201)
		 .contentType(ContentType.JSON)
		 .log().all();
}

}
