package CRUDwithBDD;

import static io.restassured.RestAssured.baseURI;
import static io.restassured.RestAssured.port;
import static io.restassured.RestAssured.when;

import org.testng.annotations.Test;

public class ReadGetSingleProject {
	@Test
	public void getsingletest() {
		baseURI = "http://localhost";
		port = 8084;

		when()
		.get("/project")
		.then()
		.log().all();

}
}
