package ParametersinApi;

import static io.restassured.RestAssured.*;

import org.testng.annotations.Test;

import io.restassured.http.ContentType;

public class PathParameter {
	@Test
	public void getSingle() {
		//Precondition
		baseURI ="http://localhost";
		port=8084;
		
		given()
		.pathParam("pid","TY_PROJ_407")		
	//Execution actions
		.when()
		.get("/projects/{pid}")
		//Validation
		.then()
		.assertThat()
		 .statusCode(200)
		 .contentType(ContentType.JSON)
		.log().all();
	}

}
