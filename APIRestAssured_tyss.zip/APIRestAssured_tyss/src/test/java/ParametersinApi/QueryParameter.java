package ParametersinApi;

import static io.restassured.RestAssured.*;

import org.testng.annotations.Test;

import io.restassured.http.ContentType;

public class QueryParameter {
	@Test
	public void querytest() {
		//Precondition
				baseURI ="https://reqres.in";
			
				
				given()
				.queryParam("page",3)
			//Execution actions
				.when()
				.get("/api/users")
				//Validation
				.then()
				.assertThat()
				 .statusCode(200)
				.log().all();
		
	}

}
