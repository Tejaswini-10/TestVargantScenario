package ValidationResponse;

import static io.restassured.RestAssured.*;

import org.testng.Assert;
import org.testng.annotations.Test;

import io.restassured.response.Response;

public class StaticvalidationResponse {
	@Test
	public void staticresponseget() {
		
		//precondition
		String expData="TY-PROJ_7683";
		baseURI ="http://localhost";
		port=8084;
		
		//action performance
        Response resp =when().get("/projects");
        
		//validation
		String	actData=resp.jsonPath().get("[0].projectId");
		Assert.assertEquals(actData,expData);
		System.out.println("data verified");
		resp.then().log().all();

	}

}
