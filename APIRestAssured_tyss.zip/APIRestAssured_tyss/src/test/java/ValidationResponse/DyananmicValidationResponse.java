package ValidationResponse;

import static io.restassured.RestAssured.*;

import java.util.List;

import org.testng.Assert;
import org.testng.annotations.Test;

import io.restassured.response.Response;

public class DyananmicValidationResponse {
	@Test
	public void  dynamictest() {
		//precondition
		String expData="TY-PROJ_7683";
		baseURI ="http://localhost";
		port=8084;
		//actions
		Response response = when().get("/projects");

		//validation
		boolean flag = false;
		List<String>pids=response.jsonPath().get("projectId");
		for(String projectId:pids) 
		{
			if(projectId.equalsIgnoreCase(expData)) 
			{
				flag=true;
			}
		}
		Assert.assertTrue(flag);
		System.out.println("TESTCASE IS PASS");
		response.then().log().all();

	}

}
