package ValidationResponse;

import static io.restassured.RestAssured.*;

import java.util.concurrent.TimeUnit;

import org.hamcrest.Matcher;
import org.hamcrest.Matchers;
import org.testng.annotations.Test;

public class ResponseTimevalidation {
@Test
public void reponsetimetest(){
	//precondition
	baseURI ="http://localhost";
	port=8084;
	//Actions
	when().get("/projects") //TY_PROJ_1207 use this projectid end point also it works
	//validation
	.then()
	.assertThat().time(Matchers.lessThan(5000L),TimeUnit.MILLISECONDS)
	.log().all();
	}
}
