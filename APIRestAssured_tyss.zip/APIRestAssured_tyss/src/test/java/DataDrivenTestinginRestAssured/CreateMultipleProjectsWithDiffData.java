package DataDrivenTestinginRestAssured;

import static io.restassured.RestAssured.*;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;


import GenericLibrary.JavaLibrary;
import io.restassured.http.ContentType;
import projectLibrary.ProjectLibrary;

public class CreateMultipleProjectsWithDiffData {
	@Test(dataProvider="getData")
	public void createProject(String createdBy, String projectName ,String status,int teamSize) {
		//Step1:precondition
		JavaLibrary jlib=new JavaLibrary();
		ProjectLibrary pLib=new ProjectLibrary(createdBy,projectName+jlib.getRandom(),status,teamSize);//pojoclass
		baseURI ="http://localhost";
		port = 8084;
		given()
		.body(pLib)
		.contentType(ContentType.JSON)
		//Step 2: Execution actions
		.when()  
		.post("/addProject")
		//Step 3: Validation
		.then()  
		.log().all();
	}

	@DataProvider(name="getData")
	public Object[][] data(){
		Object[][] data=new Object[3][4];

		data[0][0]="prabharrs";
		data[0][1]="stttle";
		data[0][2]="creattedyou";
		data[0][3]=23;

		data[1][0]="yash1";
		data[1][1]="springboot1";
		data[1][2]="created2";
		data[1][3]=2;

		data[2][0]="KKoushikk";
		data[2][1]="X-Rayy";
		data[2][2]="Createddbyme";
		data[2][3]=8;


		return data;

	}
}


