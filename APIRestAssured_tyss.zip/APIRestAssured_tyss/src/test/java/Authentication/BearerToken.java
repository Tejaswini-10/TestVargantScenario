package Authentication;

import static io.restassured.RestAssured.*;

import org.json.simple.JSONObject;
import org.testng.annotations.Test;

import io.restassured.http.ContentType;

public class BearerToken {
	@Test
	public void bearertokentest() {
		//preconditions
		baseURI ="https://api.github.com";
		JSONObject jobj=new JSONObject();
		jobj.put("name","sdetL12");
	given()
	.auth()
	.oauth2("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")//it will cm from github//selectrepo inrestapi document
	.body(jobj)
	.contentType(ContentType.JSON)
	.when()
	.post("/user/repos")
	.then().log().all();
	
	
		
		
		
	}

}
