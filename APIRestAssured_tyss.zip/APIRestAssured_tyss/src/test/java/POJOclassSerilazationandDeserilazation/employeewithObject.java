package POJOclassSerilazationandDeserilazation;

public class employeewithObject {
	
	//step1: create the keys as global variables
		String ename;
		String eid;
		int phno;
		Object spouse;
		//step2:create a constructor to initialise the variables
		public void employeeDetail(String ename,String eid,int phno,Object spouse) {	
			//super();
			this.ename=ename;
			this.eid=eid;
			this.phno=phno;
			this.spouse=spouse;
		}
		////step3:provide getters and setters to access the  variables
		public String getEname() {
			return ename;
		}
		public void setEname(String ename) {
			this.ename = ename;
		}
		public String getEid() {
			return eid;
		}
		public void setEid(String eid) {
			this.eid = eid;
		}
		public int getPhno() {
			return phno;
		}
		public void setPhno(int phno) {
			this.phno = phno;
		}
		public Object getSpouse() {
			return spouse;
		}
		public void setSpouse(Object spouse) {
			this.spouse = spouse;
		}
		
			
			
		
}

