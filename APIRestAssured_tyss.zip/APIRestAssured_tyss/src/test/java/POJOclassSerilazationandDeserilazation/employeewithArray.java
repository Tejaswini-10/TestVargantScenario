package POJOclassSerilazationandDeserilazation;

public class employeewithArray {
	String ename;
	String empid;
	String email;
	int[] phno;
	public employeewithArray(String ename,String empid,String email,int[]phno) {
		super();
		this.ename=ename;
		this.empid=empid;
		this.email=email;
		this.phno=phno;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public String getEmpid() {
		return empid;
	}
	public void setEmpid(String empid) {
		this.empid = empid;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int[] getPhno() {
		return phno;
	}
	public void setPhno(int[] phno) {
		this.phno = phno;
	}

}
