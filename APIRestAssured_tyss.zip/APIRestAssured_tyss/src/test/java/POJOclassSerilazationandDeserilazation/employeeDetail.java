package POJOclassSerilazationandDeserilazation;

public class employeeDetail {
	//step1: create the keys as global variables
	String ename;
	String eid;
	String email;
	int phno;
	//step2:create a constructor to initialise the variables
	public employeeDetail(String ename,String eid,String email,int phno) {
		super();
		this.ename=ename;
		this.eid=eid;
		this.email=email;
		this.phno=phno;
	}
	//step3:provide getters and setters to access the  variables
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public String getEid() {
		return eid;
	}
	public void setEid(String eid) {
		this.eid = eid;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getPhno() {
		return phno;
	}
	public void setPhno(int phno) {
		this.phno = phno;
	}

}
