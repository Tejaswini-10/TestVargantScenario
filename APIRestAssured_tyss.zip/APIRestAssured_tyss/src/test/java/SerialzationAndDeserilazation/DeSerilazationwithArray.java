package SerialzationAndDeserilazation;

import java.io.File;
import java.io.IOException;

import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;

public class DeSerilazationwithArray{//it will not work
	
	public static void main(String[] args) throws JsonParseException, JsonMappingException, IOException {
		
	//	int[] phNos= {9667,98888,7677777,97888};
	//	Employee emp=new Employee("Teju",001,true,phNos);
		
		ObjectMapper objMap=new ObjectMapper();
		
		Employee empRead=objMap.readValue(new File("./jsonEmployee.json"),Employee.class);
		
		System.out.println(empRead.getEmpId());
		System.out.println(empRead.getEmpName());
		System.out.println(empRead.ismStatus());
	}

}
