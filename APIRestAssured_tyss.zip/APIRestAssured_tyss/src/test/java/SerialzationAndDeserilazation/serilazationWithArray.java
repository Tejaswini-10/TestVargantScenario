package SerialzationAndDeserilazation;

import java.io.File;
import java.io.IOException;

import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;

import POJOclassSerilazationandDeserilazation.employeewithArray;

public class serilazationWithArray {
	public static void main(String[] args) throws JsonGenerationException, JsonMappingException, IOException {
		int[] phno= {1234,2347};
		employeewithArray emp=new employeewithArray("teju","ty123","ty@gmail.com",phno);
		ObjectMapper omap = new ObjectMapper();
		omap.writeValue(new File("./file1.json"),emp);
		
	}

}
	