package DifferentwaystopostRequest;

import static io.restassured.RestAssured.*;

import org.testng.annotations.Test;

import GenericLibrary.JavaLibrary;
import io.restassured.http.ContentType;
import projectLibrary.ProjectLibrary;

public class CreateProjectUsingPOJO {
	@Test
	public void pojotest() {
		JavaLibrary jlib=new JavaLibrary();
		baseURI ="http://localhost";
		port = 8084;
		//Step1.precondition
		ProjectLibrary pLib=new ProjectLibrary("sai4","stle6"+jlib.getRandom(),"createdyou9",2);
		given()
		 .body(pLib)
		 .contentType(ContentType.JSON)
		//Step 2: Execution actions
		.when()  
		 .post("/addProject")
		//Step 3: Validation
		 .then()  
		 .assertThat()
		 .statusCode(201)
		 .contentType(ContentType.JSON)
		 .log().all();
	}
}
	
	
		
		
		
		
		


