package DifferentwaystopostRequest;

import static io.restassured.RestAssured.baseURI;
import static io.restassured.RestAssured.given;
import static io.restassured.RestAssured.port;

import org.json.simple.JSONObject;
import org.testng.annotations.Test;

import GenericLibrary.JavaLibrary;
import io.restassured.http.ContentType;

public class JSonobject {
	@Test
	public void jsontest() {
		//precondition
		JavaLibrary jlib=new JavaLibrary();
		JSONObject jobj=new JSONObject();

		jobj.put("createdBy", "tejaswini34");
		jobj.put("projectName","Xylem56"+jlib.getRandom());
		jobj.put("status","Completedr");
		jobj.put("teamSize", 127);
		
		baseURI ="http://localhost";
		port = 8084;
		
		given()
		 .body(jobj)
		 .contentType(ContentType.JSON)
		
		.when()  //Step 2: perform action
		 .post("/addProject")
		 
		.then()  //Step 3: Validation
		 .assertThat()
		 .statusCode(201)
		 .contentType(ContentType.JSON)
		 .log().all();
}

}
