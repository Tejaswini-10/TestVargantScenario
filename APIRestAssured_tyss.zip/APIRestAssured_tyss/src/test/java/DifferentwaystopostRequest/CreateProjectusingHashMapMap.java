package DifferentwaystopostRequest;

import static io.restassured.RestAssured.baseURI;
import static io.restassured.RestAssured.given;
import static io.restassured.RestAssured.port;

import java.util.HashMap;

import org.testng.annotations.Test;

import GenericLibrary.JavaLibrary;
import io.restassured.http.ContentType;

public class CreateProjectusingHashMapMap{
	@Test
	public void hashmaptest() {

		JavaLibrary jlib=new JavaLibrary();
		baseURI ="http://localhost";
		port = 8084;
		//Step1.precondition
		HashMap map=new HashMap();
		map.put("createdBy","sai3");
		map.put("projectName","stle6");
		map.put("status","createdyou23");
		map.put( "teamSize",26);
		given()
		.body(map)
		.contentType(ContentType.JSON)
		//Execution actions
		.when()
		.post("/addProject")
		//Validation
		.then()
		.assertThat().statusCode(201)
		.log().all();



	}

}
