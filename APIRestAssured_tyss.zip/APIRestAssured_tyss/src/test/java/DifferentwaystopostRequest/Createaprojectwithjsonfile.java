package DifferentwaystopostRequest;

import static io.restassured.RestAssured.baseURI;
import static io.restassured.RestAssured.given;
import static io.restassured.RestAssured.port;

import java.io.File;

import org.testng.annotations.Test;

import io.restassured.http.ContentType;

public class Createaprojectwithjsonfile {
	@Test
	public void creatjsonfiletest() {
		//preconditions
		File file=new File("./src/test/resources/data.json");
		baseURI ="http://localhost";
		port = 8084;
		
		given()
		 .body(file)
		 .contentType(ContentType.JSON)
		//Step 2: Execution actions
		.when()  
		 .post("/addProject")
		//Step 3: Validation
		 .then()  
		 .assertThat()
		 .statusCode(201)
		 .contentType(ContentType.JSON)
		 .log().all();
		
	}

}
