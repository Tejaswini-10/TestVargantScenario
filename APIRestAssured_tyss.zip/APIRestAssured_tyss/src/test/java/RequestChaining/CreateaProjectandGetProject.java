package RequestChaining;

import static io.restassured.RestAssured.*;

import org.testng.annotations.Test;

import GenericLibrary.JavaLibrary;

import io.restassured.http.ContentType;
import io.restassured.response.Response;
import projectLibrary.ProjectLibrary;

public class CreateaProjectandGetProject {
	@Test
	public void Requestingtest() {
		//step1:precondition
		
		JavaLibrary jlib=new JavaLibrary();
		ProjectLibrary pLib=new ProjectLibrary("saai","sttle"+jlib.getRandom(),"created",2);
		baseURI ="http://localhost";
		port = 8084;
	 Response response = given()
				 .body(pLib)
				 .contentType(ContentType.JSON)
		//Step2:executionActions
		 .when()
		 .post("/addProject");
			
//capaturing the project id
		 
	 Object projectId = response.jsonPath().get("projectId");
	 System.out.println(projectId);//Step3:Validation
	 response.then().log().all();
	 //create get request and pass projectid as pathparameter
	 given()
	 .pathParam("pid",projectId)
	 .when()
	 .get("http://localhost:8084/projects/{pid}")
	 .then()
	 .assertThat().statusCode(200).log().all();
		
		
	}

	

}
