package CRUDwithoutBDD;

import org.testng.Assert;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class DeleteProject {
	@Test
	public void Readtest() {
		//precondition
		
			
	//STep 2: Execution performance
			Response resp = RestAssured.delete("http://localhost:8084/projects/TY_PROJ_802");
			
			//Step3: validatation
			resp.then().log().all();
			int actStatus = resp.getStatusCode();
			Assert.assertEquals(actStatus, 204);
		}
		
		
		
	}


