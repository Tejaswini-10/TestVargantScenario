package CRUDwithoutBDD;

import org.testng.Assert;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class ReadGetAllProjects {
	@Test
	public void gettest() {
		//Step 1: Precondition
		//Step 2: execution actions
		Response resp = RestAssured.get("http://localhost:8084/projects");
			
		//Step 3: Provide Validation
		resp.then().log().all();
		int actStatus = resp.getStatusCode();
		Assert.assertEquals(200, actStatus);
		}

}
