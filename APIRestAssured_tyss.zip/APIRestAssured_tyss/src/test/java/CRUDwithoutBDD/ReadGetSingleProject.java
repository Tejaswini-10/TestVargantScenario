package CRUDwithoutBDD;

import org.testng.Assert;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class ReadGetSingleProject {
	@Test
	public void gettest() {
		
			//Step 1: Precondition
			//Step 2: execution actions
			Response resp = RestAssured.get("http://localhost:8084/project");
				
			//Step 3:  Validation
			resp.then().log().all();
			int actStatus = resp.getStatusCode();
			Assert.assertEquals(200, actStatus);
	}
	}


