package CRUDwithoutBDD;

import org.json.simple.JSONObject;
import org.testng.annotations.Test;

import GenericLibrary.JavaLibrary;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class CreatePostProject {
	@Test
	public void createtest() {
		//step1:precondition
		JavaLibrary jlib=new JavaLibrary();

		JSONObject jobj=new JSONObject();

		jobj.put("createdBy", "tejaswini");
		jobj.put("projectName","Xylem"+jlib.getRandom());
		jobj.put("status","on-going");
		jobj.put("teamSize", 12);//in localhost8084 appilcation their is defect on the teamsize(0) so in output it will not get it/ not showing the team size

		RequestSpecification spec = RestAssured.given();
		spec.body(jobj);
		spec.contentType(ContentType.JSON);

		//step2:Execution actions
		Response resp = spec.post("http://localhost:8084/addProject");

		//step3:validation....201 created statuscode  //Run again it will get the 409conflict testcasefailed
		resp.then().assertThat().statusCode(201).log().all();

	}


}
