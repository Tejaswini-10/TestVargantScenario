package org;
//From a given array, make n elements rotate without using any built-in function.
//eg. given Array:[21,54,11,35,4,18], index:3; output Array: [4,18,21,54,11,35]

public class Array {

public static void main(String[] args) {
		
 int arr[]= {21,54,11,35,4,18};
 int rotateelements = arr[4];
 for(int i=arr.length-1;i<=0;i--) 
 {
	 System.out.println(arr[i]);
	 
 }
 
// //for(int i=0;i<=0;i++) 
// {
//	int num = arr[i];
// }
// 
 System.out.println("enter the rotate element" +rotateelements+arr[3]);

}
}
