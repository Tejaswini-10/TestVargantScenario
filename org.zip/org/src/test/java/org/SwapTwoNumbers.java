package org;

public class SwapTwoNumbers {

	public static void main(String[] args) {
int a=4;
int b=6;
//swap logic
int k=a=4;
  a=b=6;
 b=k=4;

	}

}
