package org;

public class RevaString {
	
	public static void main(String[] args) {
		
		String str = "Welcome To Edureka";//emocleW oT akerudE
		String[] strArray = str.split(" ");
		for (String temp: strArray){
		System.out.println(temp);
		}
		for(int i=0; i<3; i++)
		{ 
			char[] s1 = strArray[i].toCharArray(); 
			for (int j = s1.length-1; j>=0; j--)
		{
				System.out.print(s1[j]);
		}
		System.out.print(" ");
		}
		}

//	public static void main(String[] args) {
//		
//	String s = "Mobile programming india";
//	
//	String[] s1 = s.split(" ");//eliboM gnimmargorp aidni//HELLO EDUREKA
//	//Reversed string: AKERUDE OLLEH
//	
//		for(int i=0;i<s1.length-1;i++) 
//		{
//			char ch[]=s.toCharArray();	
//			for(int i1=ch.length-1;i1>=0;i1--) 
//				{
//					System.out.print(ch[i1]);
//				}
//			System.out.println(" ");
		//}
//		Test Bed
//		test Harnes
//	
//		pesticide paradox
//
//		Mobile programming india
//		eliboM gnimmargorp aidni
	
	}

}
