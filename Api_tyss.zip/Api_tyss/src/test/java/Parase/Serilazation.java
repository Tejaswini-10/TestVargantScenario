package Parase;

import java.io.File;
import java.io.IOException;

import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;

public class Serilazation {
	public static void main(String[] args) throws JsonGenerationException, JsonMappingException, IOException {
		
		int[] phNos= {9667,98888,7677777,97888};
		Employee emp=new Employee("Teju",001,true,phNos);
		
		ObjectMapper objMap=new ObjectMapper();
		objMap.writeValue(new File("./jsonEmployee.json"),emp);
	} 

}
