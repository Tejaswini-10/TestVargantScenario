package modelproject;

public class sample1test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("First git project");
		System.out.println("First git project");
		System.out.println("First git project");
		
	}

}
