package POMPages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class VtigerOrganizationInfoPage {
	//Step1:Declaration -using @FindByannotation
	@FindBy(xpath="//span[@class='dvHeaderText']") private WebElement headerText;
	//Step2:Intialization -using constructor
	public VtigerOrganizationInfoPage(WebDriver driver) {
		PageFactory.initElements(driver,this);
	}
	//Step2:Intialization -using constructor
//	public void VtigerLoginPage(WebDriver driver) {
//		PageFactory.initElements(driver,this);
//	}
	//Step3: Utilzation-Provide getters
	public WebElement getheaderText() {
		return  headerText;
	}
	//Step4:bussiness Library
	public String OrgNameInfo() {
		String orgInfo = headerText.getText();
		return  orgInfo;
	}
}
