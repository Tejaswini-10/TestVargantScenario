package POMPages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;


	public class VtigerCreateNewOrganizationPage {
		//Step1:Declaration -using @FindByannotation
		//@FindBy(xpath="//img[@alt='Create Organization...']") 
		//private WebElement createorgimage;
		
		@FindBy(xpath="//input[@name='accountname']") 
		private WebElement orgNametextbox;
		
		@FindBy(xpath="email1")
		private WebElement emailTextfield;
		
		@FindBy(xpath="accounttype")
		private WebElement typeDropDown;
		
		@FindBy(xpath="//input[@class='crmbutton small save']") 
		private WebElement savebtn;
		//Step2:Intialization using constructor
		public VtigerCreateNewOrganizationPage(WebDriver driver) {
			PageFactory.initElements(driver,this);
		}

		
//		public void VtigerLoginPage(WebDriver driver) {
//			PageFactory.initElements(driver,this);
	//
//		}
		//Step3:Generate Getters
		
		public WebElement getorgNametextbox() {
			return orgNametextbox;
		}
		public WebElement getemailTextfield(){
			return emailTextfield ;
		}
		public WebElement gettypeDropDown() {
			return  typeDropDown;
		}
		public WebElement getsavebtn() {
			return savebtn;
		}
		
		//Step4:bussiness Library

		/**
		 * This method is used to click on createorgimage
		 * @param orgname
		 * @param savebtn
		 */
		public void createNewOrg(String orgName) {
			orgNametextbox.sendKeys(orgName);
			savebtn.click();
		}
		/**
		 * this method will create new org with industry drop down
		 * @param orgName
		 * @param industrytype
		 */
	


}
