package POMPages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class VtigerOrganizationsPage {
	
	//Step1 //Step1:Declaration -using @FindByannotation
@FindBy(xpath="//span[text()='Creating New Organization']") private WebElement crateorgheading;
@FindBy(xpath="//img[@alt='Create Organization...']") private WebElement createorgimage;
public VtigerOrganizationsPage(WebDriver driver) {
	PageFactory.initElements(driver,this);
}
////Step2:Intialization -using constructor
//public void VtigerLoginPage(WebDriver driver) {
	//PageFactory.initElements(driver,this);

//}
//Step3: Utilzation-Provide getters
public WebElement getcreateorgimage() {
	return createorgimage;
}
//bussines library
/**
 * This method is used click on org link
 */
public void clickorglink() {
	createorgimage.click();
}
public void clickorgplusbtn() {
	crateorgheading.click();
}
}

