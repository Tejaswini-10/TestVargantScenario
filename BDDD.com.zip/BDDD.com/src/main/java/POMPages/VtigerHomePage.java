package POMPages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;



public class VtigerHomePage {
	//Step1:Declaration -using @FindByannotation
	@FindBy(xpath="//a[text()='Organizations']") private WebElement orglink;
	@FindBy(xpath="//a[text()='More']") private WebElement moreTab;
	@FindBy(xpath="//a[text()='Contacts']") private WebElement contacttab;
	@FindBy(xpath="//a[text()='Campaigns']") private WebElement campaignsTab;
	@FindBy(xpath="//img[@src='themes/softed/images/user.PNG']") private WebElement  adminstratorIcon;
	@FindBy(xpath="//input[@name='campaignname']") private WebElement campaignname;
	@FindBy(xpath="//a[@href='index.php?module=Users&action=Logout']") private  WebElement  signOutLink;
	@FindBy(xpath="//input[@class='crmButton small save']") private WebElement savebtn;

	//Step2:Intialization
	public VtigerHomePage (WebDriver driver) {
		PageFactory.initElements(driver,this);
	}

	//Step3:Generate Getters
	public WebElement getorglink() {
		return orglink;
	}
	public WebElement getmoreTab() {
		return moreTab;
	}
	public WebElement getcontacttab() {
		return contacttab;
	}
	public WebElement getcampaignsTab() {
		return campaignsTab;
	}

	public WebElement getadminstratorIcon() {
		return adminstratorIcon;
	}
	public WebElement getcampaignname() {
		return campaignname;
	}
	public WebElement getsignOutLink() {
		return signOutLink;
	}
	public WebElement getsavebtn() {
		return savebtn;
	}
	//Step4:bussiness library
	/**
	 * This method is used to clickon campaigntab in common page
	 * @param webdriverUtility
	 */

	public void clickCampaign(WebDriver webdriverutility) {
		((CommonUtilites.WebDriverUtility) webdriverutility).mouseHoverOnElement1(moreTab);

	}
	public void campaignclick() {
		campaignsTab.click();	
	}
	public void orglinkclick() {
		orglink.click();
	}
	/**
	 * This method is used to signout from the application
	 * @param webdriverUtility
	 */
	public void logoutAction(WebDriver webdriverutility) {
		((CommonUtilites.WebDriverUtility) webdriverutility).mouseHoverOnElement1(adminstratorIcon);
		signOutLink.click();
	}

	public void campaignname(String value) {
		campaignname.sendKeys(value);
	}

	public void savebtn() {
		savebtn.click();
	}

	public void moreTab() {
		moreTab.click();
	}

	public void contacttab() {
		contacttab.click();
	}

}



