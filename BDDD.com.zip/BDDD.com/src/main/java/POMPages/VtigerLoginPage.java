package POMPages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class VtigerLoginPage {
	
	//Step1:Declaration -using @FindByannotation
	@FindBy(xpath="//input[@name='user_name']") private WebElement userNameTextField;
	@FindBy(xpath="//input[@name='user_password']") private WebElement passwordTextFileld;
	@FindBy(xpath="//input[@id='submitButton']") private WebElement loginBtn;


	public VtigerLoginPage(WebDriver driver) {
		PageFactory.initElements(driver,this);
	}

	//Step2:Intialization -using constructor
	//public void VtigerLoginPage(WebDriver driver) {
		//PageFactory.initElements(driver,this);

	//}
	//Step3: Utilzation-Provide getters

	public WebElement getuserNameTextField() {
		return userNameTextField;
	}
	public WebElement getpasswordTextFileld() {
		return passwordTextFileld;
	}
	public  WebElement getloginBtn() {
		return  loginBtn;
	}
	//bussiness Library

	/**
	 * This method is used to Login to the application
	 * @param userName
	 * @param password
	 */
	public void loginAction(String username,String password) {
		userNameTextField.sendKeys(username);
		passwordTextFileld.sendKeys(password);
		loginBtn.click();
	}


}

