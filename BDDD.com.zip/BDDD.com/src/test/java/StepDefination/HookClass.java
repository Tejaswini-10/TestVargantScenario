package StepDefination;

import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.fasterxml.jackson.databind.deser.Deserializers.Base;

import CommonUtilites.PropertyfileUtility;
import POMPages.VtigerLoginPage;
import bddSdet36L1.genericUtility.PropertyFileUtility;
import io.cucumber.java.After;
import io.cucumber.java.AfterAll;
import io.cucumber.java.Before;
import io.cucumber.java.BeforeAll;
import io.cucumber.java.Scenario;
import io.github.bonigarcia.wdm.WebDriverManager;

public class HookClass {
	@Before(order=1)
	public void amBefore() {
		System.out.println("amBefore");	
	}
	@BeforeAll
	public static void amBeforeAll() {
		System.out.println("amBeforeAll");
	}
	@After
	public void amAfter() {
		System.out.println("amAfter");
	}
	@AfterAll
	public static void amAfterAll() {
		System.out.println("amAfterAll");
	}

	
}
	



