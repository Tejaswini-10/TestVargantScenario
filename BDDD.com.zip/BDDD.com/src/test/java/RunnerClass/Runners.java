package RunnerClass;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;


	@CucumberOptions(
			features= {"./src/test/java/Features/Createorg.feature"},
			glue= {"StepDefination"},
			dryRun=false,
			monochrome=true,
			
			plugin={
					"pretty",
					"html:BDDHtmlReports.html",
					"json:BDDJson.json"
					
	
			}
			)
			public class Runners extends AbstractTestNGCucumberTests{
			
			}


