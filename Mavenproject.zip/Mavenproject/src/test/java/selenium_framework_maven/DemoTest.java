package selenium_framework_maven;

import org.testng.annotations.Test;

public class DemoTest{
	@Test
	public void demoTest() {
		String url = System.getProperty("URL");
		String browser = System.getProperty("BROWSER");
	    String username = System.getProperty("USERNAME");
	   String password = System.getProperty("PASSWORD");
	   System.out.println("Tyss1....>Test1");
	   System.out.println(" url...........>>"+ url);
	   System.out.println("browser...........>>"+browser);
	   System.out.println("username...........>>"+ username);
	   System.out.println("password...........>>"+ password);
		
		

	}
	@Test
	public void demoTest1() {
		System.out.println("Tyss2....>Test1");
	}
}
