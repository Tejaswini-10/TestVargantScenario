package Testing1;

import org.testng.annotations.Test;

public class DDDemo1 {



	@Test
	public void demoTest() {
		String url = System.getProperty("URL");
		String browser = System.getProperty("BROWSER");
	    String username = System.getProperty("USERNAME");
	   String password = System.getProperty("PASSWORD");
	   System.out.println("Tyss1....>Test1");
	   System.out.println(" url...........>>"+ url);
	   System.out.println("browser...........>>"+browser);
	   System.out.println("username...........>>"+ username);
	   System.out.println("password...........>>"+ password);
	
	
	}
	@Test
	public void demoTest1() {
		System.out.println("Tyss223....>Test1");
	}
}


