package org;

public class headings1 {

	public static void main(String[] args) {
Web
	}

}
