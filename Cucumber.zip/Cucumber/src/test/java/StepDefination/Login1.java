package StepDefination;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;

public class Login1 {
	 WebDriver driver;
@Given("Launching the Browser")
public void launching_the_browser() {
	WebDriverManager.chromedriver().setup();
	driver=new ChromeDriver();
	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	driver.manage().window().maximize(); 
}

@Given("Entering Url")
public void entering_url() {
	driver.get("http://localhost:8888/");
}

@When("Login page is displayed enter valid username and password")
public void login_page_is_displayed_enter_valid_username_and_password() {
	driver.findElement(By.xpath("//input[@name='user_name']")).sendKeys("admin");
	driver.findElement(By.xpath("//input[@name='user_password']")).sendKeys("admin");
}
@When("Click on Login button")
public void click_on_login_button() {
	driver.findElement(By.id("submitButton")).click();  

}
@When("Login page is displayed enter valid username {string} and password {string}")
public void login_page_is_displayed_enter_valid_usernamee_and_password(String username, String password) {
	driver.findElement(By.xpath("//input[@name='user_name']")).sendKeys(username);
	driver.findElement(By.xpath("//input[@name='user_password']")).sendKeys(password);
}


@When("Click on login button")
public void click_on_loginn_button() {
	driver.findElement(By.id("submitButton")).click();   
}

@Then("Verify Homepage is displayed or not")
public void verify_homepage_is_displayed_or_not() {
	String actualtitle = driver.getTitle().trim();
	Assert.assertTrue(actualtitle.contains("Home"));
	driver.quit();
} 

@Then("Verify error msg is displayed or not")
public void verify_error_msg_is_displayed_or_not() {
    Assert.assertTrue(driver.findElement(By.xpath("//div[@class='errorMessage']")).isDisplayed());
}



}
