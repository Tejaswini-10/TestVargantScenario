package StepDefination;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;

public class CreateOrgWithIndustry {
	WebDriver driver;

	@Given("Here Browser is launching")
	public void here_browser_is_launching() {
		WebDriverManager.chromedriver().setup();
		driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

	}

	@Given("Here Entering url")
	public void here_entering_url() {
		driver.get("http://localhost:8888/");

	}

	@Given("In Login page enter the username and password and click on the login button")
	public void in_login_page_enter_the_username_and_password_and_click_on_the_login_button() {
		driver.findElement(By.xpath("//input[@name='user_name']")).sendKeys("admin");
		driver.findElement(By.xpath("//input[@name='user_password']")).sendKeys("admin");
		driver.findElement(By.xpath("//input[@id='submitButton']")).click();

	}

	@When("click on the  org link")
	public void click_on_the_org_link() {
		driver.findElement(By.xpath("//a[text()='Organizations' ]")).click();

	}

	@When("click on the create org image")
	public void click_on_the_create_org_image() {
		driver.findElement(By.xpath("//img[@alt='Create Organization...']")).click();

	}

	@When("Enter the orgnizationName {string} and  click on the Industrydropdown and click on the Education")
	public void enter_the_orgnization_name_and_click_on_the_industrydropdown_and_click_on_the_education(String string) {
		driver.findElement(By.xpath("//input[@name='accountname']")).sendKeys("SDET-36L1");

		WebElement industryDropdown = driver.findElement(By.xpath("//select[@name='industry']"));
		Select select = new Select(industryDropdown);
		select.selectByValue("Education");
		//String actualIndustryName = driver.findElement(By.xpath("//span[@id='dtlview_Industry']")).getText();


	}

	@When("click on the save button")
	public void click_on_the_save_button() {

		driver.findElement(By.xpath("//input[@title='Save [Alt+S]']")).click();

	}

@Then("verify org is create or not")

public void verify_the_org_created_or_not() {

String actualOrganisationName = driver.findElement(By.xpath("//td[@id='mouseArea_Organization Name']")).getText();
Assert.assertTrue( actualOrganisationName.contains("SDET-36L1"));
driver.quit();


	}


}
