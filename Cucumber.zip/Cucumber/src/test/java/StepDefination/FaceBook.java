package StepDefination;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;

public class FaceBook {
	WebDriver driver;
	@Given("Launch browser")
	public void launch_browser() {
		WebDriverManager.chromedriver().setup();
		driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	}

	@Given("Enter URL")
	public void enter_url() {
		driver.get("https://www.facebook.com/");

	}

	@When("Login page  displayed enter username and password")
	public void login_page_displayed_enter_username_and_password() {
		driver.findElement(By.xpath("//input[@id='email']")).sendKeys("chayatejaswini7@gmail.com");
		driver.findElement(By.xpath("//input[@type='password']")).sendKeys("@Dummy1@");
	}

	@When("Click login button")
	public void click_login_button() {
		driver.findElement(By.xpath("//button[@name='login']")).click();
	}

	@Then("Verify Homepage displayed or not")
	public void verify_homepage_displayed_or_not() {
		String actualTitle = driver.getTitle().trim();
		Assert.assertTrue(actualTitle.contains("Facebook – log in or sign up"));
		driver.quit();
		}

@When("Login page  displayed enter {string} and {string}")
public void login_page_displayed_enter_and(String username, String password) {
	driver.findElement(By.xpath("//input[@id='email']")).sendKeys("email");
	driver.findElement(By.xpath("//input[@type='password']")).sendKeys(password);
	driver.findElement(By.xpath("//button[@name='login']")).click();
}

@Then("Verify {string} displayed or not")
public void verify_displayed_or_not(String string) {
	String actualTitle = driver.getTitle().trim();
	Assert.assertTrue(actualTitle.contains("Facebook – log in or sign up"));
	driver.quit();
	}
}
