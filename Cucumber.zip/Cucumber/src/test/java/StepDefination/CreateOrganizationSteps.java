package StepDefination;

import java.time.Duration;
import java.util.List;
import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;

public class CreateOrganizationSteps {
	WebDriver driver;

	@Given("Launching a browser")
	public void launching_a_browser() {
		WebDriverManager.chromedriver().setup();
		driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	}
	@Given("Entering URL")
	public void entering_url() {
		driver.get("http://localhost:8888/");

	}
	@Given("In Login Page enter a username and password and click on login button")
	public void in_login_page_enter_a_username_and_password_and_click_on_login_button() {
		driver.findElement(By.xpath("//input[@name='user_name']")).sendKeys("admin");
		driver.findElement(By.xpath("//input[@name='user_password']")).sendKeys("admin");
		driver.findElement(By.xpath("//input[@id='submitButton']")).click();
	}
	@When("Click on a Org Link")
	public void click_on_a_org_link() {
		driver.findElement(By.xpath("//a[text()='Organizations' ]")).click();

	}
	@When("Click on create org image")
	public void click_on_create_org_image() {
		driver.findElement(By.xpath("//img[@alt='Create Organization...']")).click();

	}
	@When("Enter a org name {string} and click on save button")
	public void enter_a_org_name_and_click_on_save_button(String string) {
		driver.findElement(By.xpath("//input[@name='accountname']")).sendKeys("Sdet36-1");
		//driver.findElement(By.xpath("//input[@id='email1']")).sendKeys("email");
		driver.findElement(By.xpath("//input[@class='crmbutton small save']")).click();
	}
	@Then("Verify the org created or not")
	public void verify_the_org_created_or_not() {
		String actualOrganisationName = driver.findElement(By.xpath("//span[@class='dvHeaderText']")).getText().trim();
		Assert.assertTrue( actualOrganisationName.contains("Sdet36-1"),"comparing the created org");
		driver.quit();
	}
	
	
	@When("Enter a org name {string} and {string} click on save button")
	public void enter_a_org_name_and_click_on_save_button(String orgName, String email) {
	   
	driver.findElement(By.xpath("//input[@name='accountname']")).sendKeys(orgName);
	driver.findElement(By.xpath("//input[@id='email1']")).sendKeys(email);	
	driver.findElement(By.xpath("//input[@class='crmbutton small save']")).click();
	}
	@Then("Verify the org {string} created or not")
	public void verify_the_org_created_or_not(String orgName) {
		String actualOrganisationName = driver.findElement(By.xpath("//span[@class='dvHeaderText']")).getText().trim();
		Assert.assertTrue( actualOrganisationName.contains(orgName),"comparing the created org");
		driver.quit();
	}

@When("Enter a org name orgName and email click on save button")
public void enter_a_org_name_org_name_and_email_click_on_save_button(io.cucumber.datatable.DataTable dataTable) {
    // Write code here that turns the phrase above into concrete actions
    // For automatic transformation, change DataTable to one of
    // E, List<E>, List<List<E>>, List<Map<K,V>>, Map<K,V> or
    // Map<K, List<V>>. E,K,V must be a String, Integer, Float,
    // Double, Byte, Short, Long, BigInteger or BigDecimal.
    //
    // For other transformations you can register a DataTableType.
	
	int ranNum=new Random().nextInt(100);
	
	List<List<String>> data=dataTable.asLists();
	String orgName = data.get(1).get(0);
	driver.findElement(By.xpath("//input[@name='accountname']")).sendKeys(orgName+ranNum);
	String email = data.get(1).get(1);
	driver.findElement(By.xpath("//input[@id='email1']")).sendKeys(email);	
	driver.findElement(By.xpath("//input[@class='crmbutton small save']")).click();
	
	
}

@Then("Verify the org orgName created or not")
public void verify_the_org_org_name_created_or_not(io.cucumber.datatable.DataTable dataTable) {
    // Write code here that turns the phrase above into concrete actions
    // For automatic transformation, change DataTable to one of
    // E, List<E>, List<List<E>>, List<Map<K,V>>, Map<K,V> or
    // Map<K, List<V>>. E,K,V must be a String, Integer, Float,
    // Double, Byte, Short, Long, BigInteger or BigDecimal.
    //
    // For other transformations you can register a DataTableType.
	
	
	
	List<List<String>> data=dataTable.asLists();
	String orgName = data.get(1).get(0);
	String actualOrganisationName = driver.findElement(By.xpath("//span[@class='dvHeaderText']")).getText().trim();
	Assert.assertTrue( actualOrganisationName.contains(orgName),"comparing the created org");
	driver.quit();
}

}





