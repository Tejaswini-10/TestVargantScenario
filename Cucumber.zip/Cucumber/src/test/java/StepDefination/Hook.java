
package StepDefination;

import io.cucumber.java.After;
import io.cucumber.java.AfterAll;
import io.cucumber.java.Before;
import io.cucumber.java.BeforeAll;

public class Hook {

	@Before(order=1)
	public void amBefore() {
		System.out.println("amBefore");	
	}
	@BeforeAll
	public static void amBeforeAll() {
		System.out.println("amBeforeAll");
	}
	@After
	public void amAfter() {
		System.out.println("amAfter");
	}
	@AfterAll
	public static void amAfterAll() {
		System.out.println("amAfterAll");
	}
}
