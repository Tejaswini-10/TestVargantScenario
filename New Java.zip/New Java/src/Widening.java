
public class Widening {
	public void method1(short i)
	{
		System.out.println(i);
	}
	public void method1(byte i)
	{
		System.out.println(i);
	}
	public void method1(char i)
	{
		System.out.println(i);
	}
	public void method1(double d)
	{
		System.out.println(d);
	}
	public void method1(float f)
	{
		System.out.println(f);
	}

	public static void main(String[] args) 
	{
		WiddeningTest wt= new WiddeningTest();
		short p=5;
		byte y=10;
		wt.method1(4567887654.98);
		wt.method1(79.2);
	wt.method1(p);
		wt.method1(25);
		wt.method1(p);
		
	wt.method1('p');
wt.method1(p);
	}

}
