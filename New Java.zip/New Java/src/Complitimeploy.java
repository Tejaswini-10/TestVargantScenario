
public class Complitimeploy {

	
public void M1(int a) {
	System.out.println("Iam intezer method");
}
public void M1(float f) {
	System.out.println("im float method");
}
public class Runner{

public static void main(String[] args) {
	//Complitimeploy m=new Complitimeploy();
	//m.M1(10);
	//m.M2(10.3);
	//m.M1('A');
	//String S;
	//System.out.println(S);
	
	
}
}
}