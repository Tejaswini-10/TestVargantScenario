
public class Penntostringmethodusing {

	
	String Colour;
	int Price;
	String Brand;
		public Penntostringmethodusing(String Colour,String brand, int price) {
			this.Colour=Colour;
			this.Price=Price;
			this.Brand=Brand;
	}
 public String toString() {
	

		public static void main(String[] args) {
			
		}
		public String getColour() {
			return Colour;
		}
		public void setColour(String colour) {
			Colour = colour;
		}
		public int getPrice() {
			return Price;
		}
		public void setPrice(int price) {
			Price = price;
		}
		public String getBrand() {
			return Brand;
		}
		public void setBrand(String brand) {
			Brand = brand;
		}
		}


