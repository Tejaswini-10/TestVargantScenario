package NumberDatetiStringDateconversion;

import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;

public class NumberDatetoStringDateconvert {

	public static void main(String[] args) {
		SimpleDateFormat dateformate = new SimpleDateFormat("dd/mm/yy");
		try {
			Date date=DateFor.parse("08/07/2019");
			System.out.println("Date:"+date);
		}
		catch(ParseException e) 
		{
			e.printStackTrace();
		}

	}

}
