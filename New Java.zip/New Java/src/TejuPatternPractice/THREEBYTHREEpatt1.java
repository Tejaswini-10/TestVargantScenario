package TejuPatternPractice;

import java.util.Iterator;
import java.util.Scanner;


public class THREEBYTHREEpatt1 
{

	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number: ");
		int n =sc.nextInt();
		for (int i = 1; i<=n; i++) //lines
		{
			for (int j = 1; j<=n; j++) //spaces
			{
				System.out.print(" ");
			}

			for (int k = 1; k <=i; k++) 
			{
				System.out.println("* ");
			}
			System.out.println();

		}
	}
}
