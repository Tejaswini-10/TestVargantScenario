//singlelevel
public class InheritanceA {
InheritanceA(){
	System.out.println("iam  from A");
}
class B extends InheritanceA{
	B(){
		super();
		System.out.println("iam  from B");

	}
	class c extends A{
		c(){
			super();
			System.out.println("iam  from c");	
		}
	}
}
	public static void main(String[] args) {

	}

}
