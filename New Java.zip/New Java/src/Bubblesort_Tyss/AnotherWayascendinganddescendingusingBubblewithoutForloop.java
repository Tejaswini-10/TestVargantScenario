package Bubblesort_Tyss;

public class AnotherWayascendinganddescendingusingBubblewithoutForloop {
	public static void main(String[] args) {
		int[] a= {4,1,0,2};	
		for(int i=0;i<a.length;i++)
		{
		 for(int j=i+1;j<a.length;j++) { //increment 

				if(a[i]<a[j]){   //descedingOrder
                    int temp=a[i];
					a[i]=a[j];
					a[j]=temp;
	}
		 }
		 System.out.println(a[i]);
		}
	}
}

