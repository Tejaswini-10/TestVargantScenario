package Bubblesort_Tyss;

public class FindtheLastMaximumNumusingBubblesort {

	public static void main(String[] args) {
		int[] a= {4,1,0,2};	
		for(int i=0;i<a.length;i++)
		{
		 for(int j=i+1;j<a.length;j++) { //increment 

				if(a[i]>a[j]){//Maxim   ....descedingOrder
                    int temp=a[i];
					a[i]=a[j];//swaping
					a[j]=temp;
					//a[]={0,1,2,4}
					
					}
				}
			}
		for(int i=0;i<a.length;i++) {
			System.out.println(a[i]);//ascending order 0 1 2 4
			}
		System.out.println();
		for(int i=a.length-1;i>=0;i--) {
			System.out.println(a[i]);//descending order 4 2 1 0
		}
		
	}

}
