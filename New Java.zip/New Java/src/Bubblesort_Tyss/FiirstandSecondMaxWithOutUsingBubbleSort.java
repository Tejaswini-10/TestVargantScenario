package Bubblesort_Tyss;

public class FiirstandSecondMaxWithOutUsingBubbleSort {
public static void main(String[] args) {
		
		int[] a= {4,1,0,2};//0 1
		int fmax=a[0];//4 1 0
		int smax=a[0];//4 4 1
		for(int i=0;i<a.length;i++) 
			//i=0 0<4true     //a[i]=4
			//i=1 1<4t        //a[i]=1
			//i=2 2<4t        //a[i]=0
			//i=3 3<4t         //a[i]=2
			//i=4 4<4false terminate the loop
			{
				if(a[i]>=fmax)//4<=4t, 1<=4t, 0<=1t, 2<=0f	
				{
					if(a[i]!=fmax)//4!=4f, 1!=4t, 0!=1t
					{
						smax=fmax;//smin=4;smin=1
					}
					fmax=a[i];//fmax fmax=

				}
				else if(smax==fmax || smax<a[i]) //1==0f || 1>2f
				{
					smax=a[i];
				}
			}
			System.out.println("The first max num is = " +fmax);//fmax

			System.out.println("The Second max num is = " +smax);//smax

		}
	}


