package Bubblesort_Tyss;

public class Bubblesortdescendingorder {

	public static void main(String[] args) {
		int[] a= {4,1,0,2};//0,1,2,3(index)..length is starts from 1,2,3,4..a is array//o/p:=0,1,2,4
		for(int i=0;i<a.length;i++)//i=0 0<4t
		{
			for(int j=i+1;j<a.length;j++) { //increment 
				//j=0+1t
				if(a[i]<a[j]){//descendingbubbleshot
					//4>1t
	
					int temp=a[i];//temp=4
					a[i]=a[j];//swaping//a[i]=1
					a[j]=temp;//a[j]=4
//					System.out.println(a[i]);
//					System.out.println(a[j]);
//					System.out.println(a[i]);
				}

			}
		}
		for(int i=0;i<a.length;i++) {//TO PTINT THE SORTED ARRAY
			System.out.println(a[i]);
		}
	}



	}


