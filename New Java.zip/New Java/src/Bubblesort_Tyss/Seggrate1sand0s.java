package Bubblesort_Tyss;

public class Seggrate1sand0s {

	public static void main(String[] args) {
		int[]a= {1,0,1,0,0,0,1,1,0,1};//1 1 0 0
		int[] b=new int [a.length];
		//b[]=0    0     1    1 
		//m=  0    1     2    n=a.length-1
		int m=0;//0
		int n=a.length-1;//3
		for(int i=0;i<a.length;i++) 
			//i=0  0<4t        a[i]=1
			//i=1  1<4t        a[i]=0
			//i=2  2<4t        a[i]=1
			//i=3  3<4t        a[i]=0
			//i=4  4<4f terminate
		{
			if(a[i]==1)//1==0f else,0==0t,1==0f else,0==0t 
			{
				b[m]=a[i];//b[m]=0 ,b[m]=0
				m++;   //m++  ,m++
			}else {
				b[n]=a[i];//b[n]=1 ,b[n]=1
				n--;    //n--,n--
			}
		}
		for(int i=0;i<b.length;i++)
		{
			System.out.print(b[i]+" ");// 1 1 0 0
		
	}
	}
	}


