//Swap two Numbers WithOut using 3rd Variable using Bubble sort
package Bubblesort_Tyss;

public class Swap2NumWithoutUsing3rdVar{

	public static void main(String[] args) {
		int a=10;
		int b=20;
		a=a+b;//10+20 a=30
		b=a-b;//30-20 b=10
		a=a-b;//30-10 a=20
		System.out.println(a);
		System.out.println(b);
	}

}
