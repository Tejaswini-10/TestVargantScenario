package Bubblesort_Tyss;

public class FindthefirstMaximumNumberusingBubblesort {

	public static void main(String[] args) {
		int[] a= {4,1,0,2};	
		for(int i=0;i<a.length;i++)
		{
		 for(int j=i+1;j<a.length;j++) { //increment 

				if(a[i]<a[j]){//Maximum
                    int temp=a[i];
					a[i]=a[j];//swaping
					a[j]=temp;
					//a[]={4,2,1,0}
					//a[0]=4;
					//a[1]=1;
					//a[2]=2;
					//a[3]=0;//a[a.length-1]
					//length is 4 in order to print last number you need to print a[a.length-1]
					}
				}
			}
		System.out.println("The First Maximum Number is = "+a[0]);
	}
	}


