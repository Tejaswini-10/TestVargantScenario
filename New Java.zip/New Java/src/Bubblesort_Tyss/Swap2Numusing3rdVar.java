package Bubblesort_Tyss;

public class Swap2Numusing3rdVar {

	public static void main(String[] args) {
        int a=10;
        int b=20;
        int temp=a;//3rdVar
        a=b;
        b=temp;
        System.out.println(a);
        System.out.println(b);
        }
	}
