package Bubblesort_Tyss;

public class Findf1st2ndMinNumwithoutUsingBubblesortArray {

	public static void main(String[] args) {
		int[] a= {4,1,0,2};//0 1
		int fmin=a[0];//4 1 0
		int smin=a[0];//4 4 1
		for(int i=0;i<a.length;i++) 
			//i=0 0<4true     //a[i]=4
			//i=1 1<4t        //a[i]=1
			//i=2 2<4t        //a[i]=0
			//i=3 3<4t         //a[i]=2
			//i=4 4<4false terminate the loop
			{
				if(a[i]<=fmin)//4<=4t, 1<=4t, 0<=1t, 2<=0f	
				{
					if(a[i]!=fmin)//4!=4f, 1!=4t, 0!=1t
					{
						smin=fmin;//smin=4;smin=1
					}
					fmin=a[i];//fmin=1, fmin=0

				}
				else if(smin==fmin || smin>a[i]) //1==0f || 1>2f
				{
					smin=a[i];
				}
			}
			System.out.println("The first min num is = " +fmin);//fmin=0

			System.out.println("The Second min num is = " +smin);//smin=1

		}
	}

