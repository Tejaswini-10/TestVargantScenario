package Bubblesort_Tyss;

public class Additionof2arrays {

	public static void main(String[] args) {
		int[]a= {4,1,0,2};
		int[]b= {3,2,1,4,5};
		//o/p:-7 ,3,1,6,1

		int length=a.length;//5
		if(a.length<b.length)//5<4f 
		{ 
			length=b.length;
		}
		for(int i=0;i<length;i++)
			//i=0;0<5true
			//i=1;1<5t
			//i=2;2<5t
			//i=3;3<5t
		    //i=4;4<5t
			//i=5;5<5f
		{
			try {
				//4+3=7
				//1+2=3
				//0+1=1
				//2+4=6
				//1....>ArrayIndexOutBoundException
				System.out.println(a[i]+b[i]);//7 3 1 6
			}catch(Exception e) {
				if(a.length<b.length) //5<4f go to else part
				{
					System.out.println(b[i]);
				}else {
					System.out.println(a[i]);//1
				}
}
		}

	}
}
