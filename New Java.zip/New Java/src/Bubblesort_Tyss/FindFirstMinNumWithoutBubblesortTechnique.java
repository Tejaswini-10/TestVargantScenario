//Find the FirstMinimum number without Bubble sort Technique
package Bubblesort_Tyss;

public class FindFirstMinNumWithoutBubblesortTechnique {

	public static void main(String[] args) {
		int[] a= {4,1,0,2};//0
		int fmin=a[0];
		for(int i=0;i<a.length;i++) {
			//i=0 0<4true
			//i=1 1<4t
			//i=2 2<4t
			//i=3 3<4t
			//i=4 4<4false terminate the loop
			{
				if(fmin>a[i])//4>4f 4>1t 1>0t 0>2f{

					fmin=a[i];//fmin=1 fmin=0

			}

		}
		System.out.println("The first min num is = " +fmin);	

	}
}



