package XX;

import java.util.HashSet;

public class reverseaString {

	public static void main(String[] args) {
		String s = "Welcometosunsmart";
		//Welcometosun  smart
		String[] str = s.split(" ");
		HashSet<String> set = new HashSet<String>();
		for(int i=0;i<str.length;i++)
		{
			set.add(s);
		}
		for(String str1 : set)
		{
			int count = 0;
		
		for(int i=0;i<=0;i++)
		{
			
			if(str1==str[i])
			{
				
				count++;
			}
			
		}
		
		System.out.println(str1+" "+count);
	}
}
}
