package XX;

public class RemoveSpaceswithoutusinginbultmethod {

	public static void main(String[] args) {
		String s = "welcometosunsmart";//o/p:-welcometosun  smart
		char[] ch = s.toCharArray();
	     String s1 = "";
	     for(int i=0;i<ch.length;i++){
	         if(s.charAt(i)==' ')
	         {
	                 continue;
	         }else{
	             s1 = s1 + s.charAt(i);
	         }
	     }
	     System.out.println(s1);
	    }
	
	}


}
}
