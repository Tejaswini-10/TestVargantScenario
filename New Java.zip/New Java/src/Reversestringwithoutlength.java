//Given string without using lengthfunction
public class Reversestringwithoutlength {

	public static void main(String[] args) {
String s="liger";
char[] str=s.toCharArray();
int count=0;
for(char c:str) {
	count++;
	
}
System.out.println(count);
for(int i=count-1;i>=0;i--) {
	System.out.println(s.charAt(i));
}
	}

}
