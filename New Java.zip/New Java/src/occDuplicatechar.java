import java.util.LinkedHashSet;

//9.occarance of duplicate character in a given string
public class occDuplicatechar{

	public static void main(String[] args) {
		String s ="Tejaswini";
		LinkedHashSet<Character> set = new LinkedHashSet<Character>();
		//in linked hash set duplicates removed and maintains the order of insertion

		for(int i=0; i<s.length(); i++)
		{
			set.add(s.charAt(i));
		}
		//print each character of the set
		for (Character ch : set) 
		{

			System.out.print(ch);
		}


	}

}


