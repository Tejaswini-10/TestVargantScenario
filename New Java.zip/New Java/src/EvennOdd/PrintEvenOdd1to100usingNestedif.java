package EvennOdd;

public class PrintEvenOdd1to100usingNestedif {

	public static void main(String[] args) {
		
		      System.out.println("Odd numbers: ");       
		      printOddNumbers(1, 100);
		      System.out.println("\n");
		      System.out.println("Even numbers: ");       
		      printEvenNumbers(1, 100);
		   }
		   private static void printOddNumbers(int odd, int end)   
		   { 
		      if(odd > end)   
		         return;
		      if(odd % 2 != 0)
		      { 
		          System.out.print(odd + " ");   
		          printOddNumbers(odd + 2, end);   
		       }
		       else
		       { 
		          printOddNumbers(odd + 1, end);   
		       }
		    }
		    private static void printEvenNumbers(int even, int end)   
		    { 
		       if(even > end)   
		          return;   
		       if(even % 2 == 0)   
		       {
		          System.out.print(even + " "); 
		          printEvenNumbers(even + 2, end);   
		       }
		       else   
		       { 
		          printEvenNumbers(even + 1, end);
		       }
	}

}
