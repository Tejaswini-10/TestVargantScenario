package EvennOdd;

import java.util.Scanner;

public class PrintOdd1t0100usingWhileLoop {

	public static void main(String[] args) {
		   {
		      int oddNumber, a;
		      Scanner sc = new Scanner(System.in);  
		      System.out.print("Please enter limit to print odd numbers: ");  
		      oddNumber = sc.nextInt();
		      a = 1;
		      System.out.print("Odd numbers: ");  
		      while(a <= oddNumber)  
		      {  
		         System.out.print(a + " ");   
		         a = a + 2;  
		      }
		      sc.close();
	}

}
}
