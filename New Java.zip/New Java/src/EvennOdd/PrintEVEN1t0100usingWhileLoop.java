package EvennOdd;

import java.util.Scanner;

public class PrintEVEN1t0100usingWhileLoop {

	public static void main(String[] args) {
		      int evenNumber, a;
		      Scanner sc = new Scanner(System.in);  
		      System.out.print("Please enter limit to print even numbers: ");  
		      evenNumber = sc.nextInt();
		      a = 2;   
		      System.out.print("Even numbers: ");  
		      while(a <= evenNumber)  
		      {
		         System.out.print(a + " ");   
		         a = a + 2;
		      }
		      sc.close();
	}

}
