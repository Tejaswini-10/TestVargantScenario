import java.util.HashSet;

//18.Printvowlespresentinstring
public class Printvowlespresentinstring {

	public static void main(String[] args) {
		
		String s="Tejaswini";
		HashSet<Character> h=new HashSet<Character>();
		for(int i=0;i< s.length();i++) {
			h.add(s.charAt(i));
		}
            int i;
			char c=s.charAt(i);
            if(isVowel(c))
            {
                h.add(c);
            }
        
 
        System.out.println("Vowels are:");
        for (Character c1:h) {
            System.out.print(" "+c1);
        }
	
        public static boolean isVowel(char character)
        {
     
            if(character=='a' || character=='A' || character=='e' || character=='E' ||
                    character=='i' || character=='I' || character=='o' || character=='O' ||
                    character=='u' || character=='U'){
                return true;
            }else{
                return false;
	

	}
        }
	}


