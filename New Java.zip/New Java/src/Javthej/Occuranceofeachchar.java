package Javthej;
//Count occ of each char in string//I/P:-Java ,o/p:-J=1,a=2,v=1;


import java.util.LinkedHashSet;

public class Occuranceofeachchar {

	public static void main(String[] args) {

		String s="Java";
		//char[] s1 = s.toCharArray();
		LinkedHashSet<String>set=new LinkedHashSet<String>();
		for(int i=0;i<s.length();i++)
		{
			set.add(s.charAt(i));
		}
		for(String c : set)
		{
			int count=0;
			int i;
			if(c == s(i))
			{
				count++;
				for(int i1=0;i1<s.length();i1++)
				{
					System.out.println(c+" "+count);
				}

			}
		}
	}

	private static String s(int i) {
		// TODO Auto-generated method stub
		return null;
	}

	
	}
	





