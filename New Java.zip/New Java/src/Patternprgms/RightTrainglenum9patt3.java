package Patternprgms;

public class RightTrainglenum9patt3 {

	public static void main(String[] args) {
		int n=7;
		int k=0;
		for(int i=0;i<n;i++) 
		{
			for(int j=0;j<n;j++) {
				//1       
				//2 3      
				//4 5 6     
				//7 8 9 1    
				//2 3 4 5 6   
				//7 8 9 1 2 3  
				//4 5 6 7 8 9 1 
			if(i>=j) 
			{
				System.out.print(k++%9+1 +" ");
			}else {
				System.out.print(" ");
			}
		}
		System.out.println();
	}
	}
}
