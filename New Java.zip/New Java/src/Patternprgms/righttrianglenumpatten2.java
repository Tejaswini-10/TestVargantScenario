package Patternprgms;

import java.util.Scanner;

public class righttrianglenumpatten2 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int n = sc.nextInt();
		int k=0;
		for(int i=0;i<n;i++) {
			for(int j=0;j<n;i++) 
			{
				if(i>=j) {
					System.out.print(k++%5+1 +" ");
				}else {
					System.out.print(" ");
				}
			}
			System.out.println();
		}
	}

}
