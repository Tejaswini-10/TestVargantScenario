package Patternprgms;

public class DownfivestarPyramidprgm {

	public static void main(String[] args) {
		int n=5;
		for(int i=n;i>0;i--)//rows
		{
			for(int j=n;j>0;j--) 
			{
				if(i>=j) 
				{
					System.out.print("* ");//* * * * *
					                      //  * * * * 
					                     //    * * *
					                    //      * *
					                   //        *
				}else {
					System.out.print(" ");
				}
			}

			System.out.println();
		}
	}
}


