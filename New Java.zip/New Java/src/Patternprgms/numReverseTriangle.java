package Patternprgms;

public class numReverseTriangle {

	public static void main(String[] args) {
		int n=5;
		for (int i=n;i>0;i--)
		{
			for(int j=n;j>0;j--) {
				if(i>=j) {
					System.out.print(i+" ");//5 5 5 5 5
					                       //  4 4 4 4
					                      //    3 3 3 
					                     //      2 2
					                    //        1
				}else {
					System.out.print(" ");
				}
			}
			System.out.println();
		}
	}

}
