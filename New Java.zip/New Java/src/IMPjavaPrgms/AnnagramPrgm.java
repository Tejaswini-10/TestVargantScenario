package IMPjavaPrgms;

import java.util.Arrays;

public class AnnagramPrgm 
{

	public static void main(String[] args) 
	{
		String s1="Raman";
		String s2="Manar";//two strings are said to be anagram if we can from one 
		                 //string by arranging the characters of another string

		//convert to LowerCase
		s1=s1.toLowerCase();
		s2=s2.toLowerCase();

		//check if length is same

		if(s1.length()==s2.length()) 
		{
			char[] ch1 = s1.toCharArray();
			char[] ch2 = s2.toCharArray();
			//System.out.println(ch1);
			//System.out.println(ch2);
			Arrays.sort(ch2);
			Arrays.sort(ch1);

			boolean result = Arrays.equals(ch1, ch2);

			if(result) 
			{
				System.out.println(s1+" and "+s2+" are anagram");
			}
			else 
			{
				System.out.println(s1+" and "+s2+" are not anagram");
			}
	}
	}
}


