package IMPjavaPrgms;

public class HAPPYnumber {

	public static void main(String[] args) {

	}

}
