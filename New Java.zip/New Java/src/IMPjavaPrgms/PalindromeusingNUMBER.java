package IMPjavaPrgms;

public class PalindromeusingNUMBER {

	public static void main(String[] args) {
		int n = 131;
		int rev=0,temp=n;
		do {
			int d=n%10;
			rev=(rev*10)+d;
			n=n/10;
		}while(n!=0);
		if(rev==temp)
			System.out.println(temp+" is a palindrome");
		else
			System.out.println(temp+" is not a palindrome");
	}

}
