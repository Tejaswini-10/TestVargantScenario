package IMPjavaPrgms;

import java.util.Scanner;

public class ArmStrongNumber {

	public static void main(String[] args)
	{
	
	int n = 131;
	int sum=0,sum1=n;
	while (n!=0) 
	{
		int d = n%10;
		sum1=sum1+d*d*d;
		n=n/10;
	}
	if (sum1==n)
		System.out.println(n+"is an arm strongNumber");
	else
		System.out.println(n+"is an not arm strongNumber");
		}

	}


