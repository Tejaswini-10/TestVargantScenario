package IMPjavaPrgms;

public class Swap2NumberswithoutUsing3rdVariable {

	public static void main(String[] args) {
		int n1=20;
		int n2=30;
		int temp;
		System.out.println("before swap"+n1+" "+n2);
		temp=n1;
		n1=n2;
		n2=temp;
		
		System.out.println("after swap"+n1+" "+n2);
	}

}
