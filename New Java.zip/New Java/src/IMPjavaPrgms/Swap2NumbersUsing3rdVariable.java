package IMPjavaPrgms;

public class Swap2NumbersUsing3rdVariable {

	public static void main(String[] args) {
		int n1=20;
		int n2=30;
		
		System.out.println("Before swap"+n1+","+n2);
		n1=n1+n2;
		n2=n1-n2;
		n1=n1-n2;
		System.out.println("after swap"+n1+","+n2);

	}

}
