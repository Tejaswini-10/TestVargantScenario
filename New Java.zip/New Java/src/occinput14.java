import java.util.ArrayList;
import java.util.LinkedHashSet;
//combination of similar int
public class occinput14 {

	public static void main(String[] args) {
     String s="123423413241";
     LinkedHashSet<Character> Lh = new LinkedHashSet<Character>();
		
		for(int i=0;i< s.length();i++) {
			Lh.add(s.charAt(i));
		}
		
		for(Character ch: Lh) {    //
			int count=0;
			for(int i=0;i< s.length();i++) {
				if(ch.equals(s.charAt(i))) {
					System.out.print(ch);
				}
			}
			System.out.print(" ");			
		}

	}

}
