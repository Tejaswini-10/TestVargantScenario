//15.Positionofchargivenstring
public class Positionofchargivenstring {

	public static void main(String[] args) {

	}

}
