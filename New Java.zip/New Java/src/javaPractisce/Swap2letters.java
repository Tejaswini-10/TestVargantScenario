package javaPractisce;

public class Swap2letters {

	public static void main(String[] args) 
	{
	String str="Tejaswini";//o/p;-iejaswinT
	System.out.println(s(str));
	}
public static String s(String str)
{
	if(str.length()<2)
		return str;
	return(str.substring(str.length()-1)
			+str.substring(1, str.length() -1)
			+str.substring(0,1));//iejaswinT(0,1)//iejaswinTejasw(0,6)
			
}

}
