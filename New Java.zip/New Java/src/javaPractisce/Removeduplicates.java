package javaPractisce;

import java.util.LinkedHashSet;

public class Removeduplicates {

	public static void main(String[] args) {

		int []ar= {1,2,1,2,3,5,3,7,4,1,8,8,8};

		LinkedHashSet<Integer>lhs=new LinkedHashSet<Integer>();
		for(int i=0;i<ar.length;i++) 
		{
			lhs.add(ar[i]);
		}
		for(Integer num :lhs)//for each loop..iteration
		{
			int sum=0;
			for(int j=0;j<ar.length;j++) 
			{
				if(num==ar[j])
				{
					sum=sum+ar[j];
				}

			}
			System.out.println(sum);
		}

	}
}
