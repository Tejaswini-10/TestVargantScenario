package javaPractisce;

import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.util.Scanner;

public class jdbcpro {
	public void updatedatabase() {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Name :");
		String	name =sc.next();
	Driver driverref=new Driver();
	DriverManager.registerDriver(driverref);
	Connection conn = DriverManager.getConnection("");
		


	}

}
