package javaPractisce;

import java.util.HashMap;

import map.values;

//WICKETS
public class ScenariobaswedquestioninCricketbuzz1 {

	public static void main(String[] args) {
		HashMap map = new HashMap<>();
		map.put("Southee", 2);
		map.put("Santner",2);
		map.put("M Bracewell", 2);
		map.put("Tickner", 0);
	Collection list = new map.values();
Arraylist	list = new ArraryList<Integer>(values);
	

	}

}
