package javaPractisce;

import java.util.Iterator;

public class SegerigatedtheString {

	public static void main(String[] args) {

		String s = "%&abcd%TE*JU22";
		int i;
		char[]a=s.toCharArray();

		String alpha = " ";
		String num = " ";
		String speciachar = " ";

		int countAlpha = 0;
		int countnum = 0;
		int countSpecialchar = 0;

		for(int i1=0;i1<a.length;i1++) 
		{
			System.out.println(a[i1]+" ");	
		}
		
		for(int i2=0;i2<a.length;i2++) {
			if(a[i2]>='a'&& a[i2]<='z'||a[i2]>='A'&& a[i2]<='z') {

				alpha=alpha+a[i2];
				countAlpha++;
			}
			else if(a[i2]>='0'&& a[i2]<='9') {
				num=num+a[i2];
				countnum++;
			}
			else {
				speciachar = speciachar+a[i2];
				countSpecialchar++;
			}

		}
		System.out.println(alpha+" "+countAlpha);
		System.out.println(num+" "+countnum);
		System.out.println(speciachar+" "+countSpecialchar);
	}
}
