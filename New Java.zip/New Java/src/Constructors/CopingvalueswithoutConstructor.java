package Constructors;

public class CopingvalueswithoutConstructor {
	 
	    int id;  
	    String name;  
	    
	    CopingvalueswithoutConstructor(int i,String n)
	    {  
	    id = i;  
	    name = n;  
	    }  
	    CopingvalueswithoutConstructor(){}  
	    void display()
	    {
	    	System.out.println(id+" "+name);
	    }  
	   
	    public static void main(String args[]){  
	    	CopingvalueswithoutConstructor s1 = new CopingvalueswithoutConstructor(111,"Karan");  
	    	CopingvalueswithoutConstructor s2 = new CopingvalueswithoutConstructor();  
	    s2.id=s1.id;  
	    s2.name=s1.name;  
	    s1.display();  
	    s2.display();  
	   }  
	}  


