package Constructors;

public class ParameterisedConstructor {
	//Java Program to demonstrate the use of the parameterized constructor.  
	  
	    int id;  
	    String name;
	    int marks;
	    int rollnum;
	    //creating a parameterized constructor  
	    ParameterisedConstructor(int i,String n,int k,int r)
	    {  
	    id = i;  
	    name = n; 
	    marks=k;
	    rollnum=r;
	 
	    }  
	    //method to display the values  
	    void display()
	    {
	    	System.out.println(id+" "+name+" "+marks+" "+rollnum+" ");
	    }  
	   
	    public static void main(String args[]){  
	    //creating objects and passing values  
	    	ParameterisedConstructor s1 = new ParameterisedConstructor(111,"Karan",23,5);  
	    	ParameterisedConstructor s2 = new ParameterisedConstructor(222,"Aryan",233,6);  
	    //calling method to display the values of object  
	    s1.display();  
	    s2.display();  
	   }  

}

