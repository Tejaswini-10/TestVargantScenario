package INTERVEIWJAVAPRGMS;

public class addlasttwodigits {

	public static void main(String[] args) {
	int[]	num={1,2,34,5,6,7,89,7,3,1};
	int add 4;

			
	}

}
