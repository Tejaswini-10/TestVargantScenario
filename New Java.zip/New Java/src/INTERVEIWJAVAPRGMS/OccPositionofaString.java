package INTERVEIWJAVAPRGMS;


import java.util.HashSet;
import java.util.Iterator;

public class OccPositionofaString 
{//occurance of each Word
	public static void main(String[] args)
	{
		String s="HI HELLO HELLO HELLO HI BYE BYE BYE";//HI=2//HELLO=3//BYE=3
		String[] str = s.split(" ");
		//step1:- store each word of sentence inn set
		HashSet<String> set = new HashSet<String>();	

		for(int i=0; i<str.length; i++)
		{
			set.add(str[i]);
		}
		//compare each word of sentence with String array
		for (String word : set) 
		{
			int count=0;

			for (int i = 0; i < str.length; i++)
			{
				if (word.equals(str[i]))
				{
					count ++;
				}

			}
			System.out.println(word+" "+count);
		}

	}
}


