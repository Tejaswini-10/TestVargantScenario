package INTERVEIWJAVAPRGMS;

public class CheckthegivenINTEGERpresentornot {

	public static void main(String[] args) {
		int[] num={3,3,5,7,9,6,4};//output:-6 is found.
		int toFind=6;
		boolean found = false;
		for(int n:num) 
		{
			if(n==toFind) 
			{
				found=true;
				break;
			}
		}
		if(found)
			System.out.println(toFind +" is found.");
		else
			System.out.println(toFind +" is not found");
	}
}
