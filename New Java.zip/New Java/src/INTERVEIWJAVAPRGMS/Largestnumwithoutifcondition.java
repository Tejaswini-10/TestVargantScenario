package INTERVEIWJAVAPRGMS;

public class Largestnumwithoutifcondition {
	
	//Function to find the largest 2numbers
	static int largestNum(int a,int b) 
	{
		return a*((a/b)>0 ?1:0)+b*((b/a)>0?1:0);
		
	}
	//Driver code

	public static void main(String[] args) {
		int a=3,b=12;//o/p:-12
		System.out.println(largestNum (a,b));
	}

	}


