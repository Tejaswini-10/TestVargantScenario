package INTERVEIWJAVAPRGMS;

import java.util.HashSet;
import java.util.LinkedHashSet;

public class Printonlyduplicatevalues 
{

	public static void main(String[] args) 
	{
		String s = "chayatejaswini";//a 3 i 2
		LinkedHashSet<Character> set=new LinkedHashSet<Character>();
		//HashSet<Character> set=new HashSet<Character>();
		
		for(int i=0;i<s.length();i++)
		{
			set.add(s.charAt(i));
		}
		for(Character c:set)
		{
			int count=0;
			for(int i=0;i<s.length();i++)
			{
				if(c==s.charAt(i))
				{
					count++;
				}
			}
			if(count>=2)
			{
				System.out.println(c+" "+count);
			}

		}
	}

}
