package INTERVEIWJAVAPRGMS;

public class SpiltgivenstringinWORDType {

	public static void main(String[] args) {
		String s = "This|is|simple|text";
		String[] s1 = s.split("|");
		//System.out.println(s);
		
		
	for(String w:s1)
		{
		System.out.println(w);
		}
	}

}
