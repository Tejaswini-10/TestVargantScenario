package INTERVEIWJAVAPRGMS;

public class Seegegatecharnum 
{

	public static void main(String[] args)
	{
		String str = "abc123xyz7";//1237
		                         //abcxyz
		int i;  
		String ch="";  
		String num="";  
		for(i = 0; i < str.length(); i++)
		{  
			char c = str.charAt(i);  
			if( '0' <= c && c <= '9' )  
				ch=ch+c;  
			if( 'a' <= c && c <= 'z' )  
				num=num+c;  
		}  
		System.out.println(ch);  
		System.out.println(num);  
	}
}


