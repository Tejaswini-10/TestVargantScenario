package INTERVEIWJAVAPRGMS;

import java.util.LinkedHashSet;

public class RemoveDuplicates {

	public static void main(String[] args) 
	{
		int[]a={1,11,2,2,2,22,44,88,22,88};//output;-1,11,2,44,88,22
		LinkedHashSet<Integer> set = new LinkedHashSet<Integer>();
		for (int i = 0; i < a.length; i++) //store the values in set
		{
			set.add(a[i]);
		}

		for (Integer num : set) //foreachloop  iteration
		{
			int count = 0;
			for (int i = 0; i < a.length; i++) 
			{
				if(num==a[i])
				{
				count++;	
				}
				
			}
			 System.out.println(num+ +count);
		}
  
	}

}
