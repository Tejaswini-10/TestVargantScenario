package INTERVEIWJAVAPRGMS;

public class ArrayMinandMaxprogram {

	public static void main(String[] args) {

	}

}
