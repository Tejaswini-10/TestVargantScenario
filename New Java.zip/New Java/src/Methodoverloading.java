
public class Methodoverloading {

		public void m1(int a) {
			System.out.println("iam int  method");
		}
		public void m1(float f) {
			System.out.println("iam a float method");
		}

		public static void main(String[] args) {

			MethodOverLoading mvl = new MethodOverLoading();
			mvl.m1(10);
			//mvl.m1(10.2);
			mvl.m1('a');
			
			
		}
	}

}
