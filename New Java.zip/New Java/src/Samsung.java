//Abstractrealtimeexample extends Reverseevennumusingforloop
public class Samsung {

public void calling(){
System.out.println("one rupee");//1Rs/1min
}
public void Camera(
		2mp
		){
		}

		}

Class SamsungGalaxy extends Samsung{

public void Calling(
		45 Paisa/!min
		){}
		Camera(
		4mp
		){}

		PatternLock(){

		}

		}

		Class SamsungASeries extends Samsung{

		Calling(
		30 paisa/1 min
		){}
		Camera(
		8mp
		){}

		Games(){

		}
		}


		abstarct class Samsung{

		Calling()
		{
		30paisa/1 min
		}

		Camera();

		}



		class SamsungGalaxy extends Samsung{
		Calling()
		{
		30paisa/1 min
		}

		camera(){
		4mp
		}
		PatternLock(){

		}
		}

		class SamsungASeries extends Samsung{

		Calling()
		{
		30paisa/1 min
		}

		camera(){
		8mp
		}

		Games(){

		}
		}




		class SamsungZSeries extends SamsungGalaxy , SamsungASeries{



		}


		interface Calling{

		Calling();

		}

		interface Camera{

		camera();

		}

		interface PatternLock{

		patternLock();

		}

		interface FrontCamera{

		frontCamera();

		}

		interface Games{

		games();

		}

		interface FingerPrint{
		fingerPrint();

		}


		Class SamsungZSeries implements Calling,Camera,PatternLock,Games{

		calling(){
		30 paisa/1 min
		}

		camera(){
		8mp
		}

		patternLock(){
		"hjsgdjs"
		}

		games(){
		"PubG"
		}

		frontCamera(){
		4mp
		}

		}



		Class SamsungGen1 implements Calling,Camera,FingerPrint,Games,FrontCamera{

		calling(){
		30 paisa/1 min
		}

		camera(){
		12mp
		}

		FaceUnLock(){
		"//////"
		}

		games(){

		}

		frontCamera(){
		8mp
		}

		}














}
}
