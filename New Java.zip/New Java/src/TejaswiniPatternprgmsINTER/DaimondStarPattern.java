package TejaswiniPatternprgmsINTER;

public class DaimondStarPattern {

	public static void main(String[] args) {
		int n=5;
		for (int i = 1; i<=n; i++)//no of lines
		{
			for (int j = 1; j <=n; j++) //no of spaces
			{
				System.out.print(" ");
			}
			for(int j=1;j<=2*i-1;j++)//no of stars
			{
				System.out.print("*");
			}
		
		}
		System.out.println();
	}

}
