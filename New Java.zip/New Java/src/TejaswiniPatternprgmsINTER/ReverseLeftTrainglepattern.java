package TejaswiniPatternprgmsINTER;

public class ReverseLeftTrainglepattern {

	public static void main(String[] args) {
int n = 5;
for(int i=1; i<=5; i++)
{
    for(int k=1; k<=i; k++)
    {
        System.out.print(" ");
    } 
    for(int j=1; j<=5-i+1; j++)
    {
        System.out.print("*");
    } 
    System.out.println();
}
} 

//for (int i = n; i >=1 ; i--) //no of lines
//{
//	for(int j=1;j<=n;j++) //no of spaces
//	{
//		System.out.print(" ");
//	}
//	for(int j=1;j<=i;j++) //no of stars
//	{
//		System.out.print("*");
//	}
//	System.out.println();
//}
	}


