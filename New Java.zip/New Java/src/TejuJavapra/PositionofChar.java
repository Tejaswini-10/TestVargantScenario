package TejuJavapra;

public class PositionofChar 
{

	public static void main(String[] args) 
	{
		String s = "tejaswini chaya";
		char[] ch = s.toCharArray();
		System.out.print(ch);
		for(int i=0;i<s.length();i++) 
		{
			System.out.println(ch[i]+" position"+(i+1));	
		}
	}

}
