package TejuJavapra;

import java.sql.Array;

public class ArrayMAX {

	public static void main(String[] args) {
		int arr[]={2,3,5,7};
		int max=arr[0];
		for (int i = 1; i < arr.length; i++) 
		{
			if(arr[i]>max) 
			{
				max=arr[i];
			}
			
		}
		System.out.println("Largest number is"+max);
	}

}
