package TejuJavapra;

public class Palindrome {

	public static void main(String[] args) {
		String s = "level";
		String rev = "";
		for(int i=0;i<s.length();i++) 
		{
			rev=s.charAt(i)+rev;
		}
		if(s.equals(rev)) 
		{
			System.out.println("given string "+s+" is palindrome");
		}
		else {
			System.out.println("given string "+s+" is not a palindrome");
		}

	}

}
