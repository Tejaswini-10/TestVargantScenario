package TejuJavapra;

import java.util.Scanner;

public class Righttriangleabcpattern 
{

	public static void main(String[] args) {

		char i;
		char j;
		//Scanner sc = new Scanner(System.in);
		//int n = sc.nextInt();
		for( i='a';i<='e';i++) 
		{
			for( j='a';j<=i;j++)
			{
				System.out.print(j+" ");//a 
				//                        a b 
				//                        a b c 
				//                        a b c d 
				//                        a b c d e
				
			}
					System.out.print("\n");
				}

			}
		}
	

