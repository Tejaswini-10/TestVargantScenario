package TejuJavapra;

import java.util.Scanner;

public class ReverseSentance {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		String str=sc.next();
		String s="java selenium pthython Maven";
		System.out.println("enter the Sentance");

		String rev="";
		String s1[]=str.split(" ");
		for(int i=s1.length-1;i>=0;i--){
			rev=rev+" "+s1[i];
			System.out.println("Reverse sentance is:"+rev);
			sc.close();
		}	}

}
