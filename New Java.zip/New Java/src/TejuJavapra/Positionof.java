package TejuJavapra;

import java.util.ArrayList;

public class Positionof {

	public static void main(String[] args) {
		String s="tester";
		 s ss = toLowercase();
		ArrayList<Character>al=new ArrayList<Character>();
		for(int i=0;i<s.length();i++)
		{
			al.add(s.CharAt(i));
		}
		for(Character ch:al)
		{
			int count=0;
			int i;
			if(ch==(i+1))
			{
				for(int i1=0;i1<s.length();i1++)
				{
					count++;
					System.out.println(ch+" "+count);
					break;

				}
			}
		}
	}

	private static void toLowercase() {
		// TODO Auto-generated method stub
		
	}
}
