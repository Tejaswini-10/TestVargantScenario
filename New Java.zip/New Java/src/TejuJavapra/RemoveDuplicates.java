package TejuJavapra;

import java.util.HashSet;
import java.util.LinkedHashSet;


public class RemoveDuplicates {

	public static void main(String[] args) {
		LinkedHashSet<Character>lh=new LinkedHashSet<Character>();
		
		String s="amma";
		for(int i=0;i<s.length();i++)
		{
		lh.add(s.charAt(i));
		}
		System.out.print(lh);
		}
			}
	


