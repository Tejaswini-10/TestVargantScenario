package TejuJavapra;

import java.util.HashSet;

public class numofoccpra {

	public static void main(String[] args) {
		int a[]={1,2,3,4,4,5,5,6};
		HashSet<Integer>set=new HashSet<Integer>();
		for(int i=0;i<a.length;i++)
		{
			set.add(a[i]);
		}
		for(Integer i:set)
		{
			int count=0;
			{
				for(int i1=0;i1<a.length;i1++)
					if(i1==(a[i1]))
					{
						count++;
					}
			}
			System.out.println(i+" = "+count);
		}
	}
}






