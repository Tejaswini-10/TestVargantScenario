package TejuJavapra;



public class CreateConstructorforStudent 
{
	String name;
	int rollnum;
	int marks;
	int id;
	CreateConstructorforStudent(String p,int q,int r,int s)
	{
		name=p;
		rollnum=q;
		marks=r;
		id=s;
	}


	public void show() 
	{
		System.out.println("Enter name:"+name);
		System.out.println("Enter rollnum:"+rollnum);
		System.out.println("Enter marks:"+marks);
		System.out.println("Enter id:"+id);
	}

class Driver{

	public static void main(String[] args) 
	{
		CreateConstructorforStudent c1=new CreateConstructorforStudent("teju", 2, 3, 4);
		c1.id=4;
		c1.marks=3;
		c1.name="teju";
		c1.rollnum=2;
		c1.show();

	}
}
}




