package TejuJavapra;

import java.util.Scanner;

public class ArmStrong {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int n = sc.nextInt();
		System.out.println("enter the number: ");
		int sum=0;sum=n;
		while(n!=0)
		{
			int d = n%10;
			sum=sum+d*d*d;
			n=n/10;
		}
		if(sum==n)
			System.out.println(n+"is an armstrong no");
		else {
			System.out.println(n+"is not an armstrong no");
		}
	}

}
