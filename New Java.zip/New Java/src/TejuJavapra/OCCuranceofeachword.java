package TejuJavapra;

import java.util.HashSet;

public class OCCuranceofeachword {

	public static void main(String[] args) {
		String s = "WELCOME TO INDIA TO PATTIKONDA";
		String[] str = s.split(" ");
		HashSet<String> set= new HashSet<String>();

		for(int i=0;i<str.length;i++)
		{
			set.add(str[i]);
		}
		for(String word:set)
		{
			System.out.println(word+" ");
		}
//			int count=0;
//
//			for(int i=0;i<str.length;i++)
//			{
//				if(word.equals(str[i]))
//					count++;
//			}
//			//if(count>=2)//print only duplicates
//			//if(count==1)//unique print
//			System.out.println(word+" "+count);
		}

	}

