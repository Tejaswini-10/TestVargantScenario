package TejuJavapra;

public class Seggchnumspl 
{
	public static void main(String[] args) 
	{
		String s="ABC@123^";
		String ch="",num="",spl="";
		for(int i=0;i<s.length();i++)
		{
			if(s.length()>='A'&& s.length()<='Z'||s.length()>='a'&& s.length()<='z')
			{
				ch=ch+s.charAt(i);

			}
			else if(s.length()>='0'&& s.length()<='9')
			{
				num=num+s.charAt(i);

			}
			else {
				spl=spl+s.charAt(i);
			}

			System.out.println(ch);
			System.out.println(num);
			System.out.println(spl);
		}
	}}



