//Reverse a given string using 2nd variable
public class Reversestring2ndvaraible {

	public static void main(String[] args) {
String s="liger";
String rev="";
for(int i=0;i<s.length();i++) {
	rev=s.charAt(i)+rev;
	
}
System.out.println(rev);	}

}
