
public class Test {
	
	public void M1(String s ) {
		System.out.println("Iam intezer method");
	}
	public void M1(Object o) {
		System.out.println("im float method");//nonprimitive//methodoverloading
	}
	public class Runner{


	public static void main(String[] args) {
Test t= new Test();
t.M1("Java");// java is string
t.M1(new Object());//object..
t.M1(null);
String s;
System.out.println(S);
Test t=null;
	}
	}
}
