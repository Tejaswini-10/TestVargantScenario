package StringProgramms;

public class Compressastring {

	public static void main(String[] args) {

		String s = "aaabbccdd";//3a2b2c2d
		int count=1;
		for (int i = 0; i <s.length(); i=i+count) 
		{    count=1;
		for (int j = i+1; j < s.length(); j++) 
		{
			if (s.charAt(i)==s.charAt(j)) 
			{
				count++;
			}
			else 
			{
				break;
			}
		}
		System.out.print(count+""+s.charAt(i));	
		}
	}
}
