package group5;

public class India {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     String s="India";
    String sum = null;
  for (int i = 0; i < s.length(); i++) {
	 
	    String value=sum+s.charAt(i);
	    
	System.out.println(value);
}
	}

}
