package group5;

import java.util.ArrayList;

public class OddAndEvenNUmber {

	public static void main(String[] args) 
	{
		int[] a={1,2,3,6,5,4,8,10};
		for (int i : a)
		{
			
			if(a[i]%2==0)
			{
			System.out.println(a[i]);	
			}
			
			
		}
		
		
	}

}
