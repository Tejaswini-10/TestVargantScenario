
public class Father {
	
public void  Money() {

}


public void Car() {
	
}
class Son extends Father{
	
}
public static void main(String[] args) {
Son s=new Son();
s.Car();
}
}

