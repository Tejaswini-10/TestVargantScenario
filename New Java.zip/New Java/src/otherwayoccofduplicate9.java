//9.occurance of duplicate character in a given string
import java.util.HashSet;
import java.util.LinkedHashSet;

public class otherwayoccofduplicate9 {

	public static void main(String[] args) {
		String s="india";//i=2,n=1,d=1,a=1
		LinkedHashSet<Character> hs=new LinkedHashSet<Character>();
		for(int i=0;i<s.length();i++) {
			hs.add(s.charAt(i));
		}
		for(Character ch: hs) {    //i,d,a,n
			int count=0;
			for(int i=0;i<s.length();i++) {
				if(ch.equals(s.charAt(i))) {
					count++;
				}
			}
			if(count>1)
			System.out.println(ch+":"+count);			
		}
	}

}
