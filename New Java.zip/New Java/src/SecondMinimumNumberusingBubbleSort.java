
public class SecondMinimumNumberusingBubbleSort {

	public static void main(String[] args) {
		int[] a= {4,1,0,2};	
		for(int i=0;i<a.length;i++)
		{
			for(int j=i+1;j<a.length;j++) { //increment 

				if(a[i]>a[j]){//Ascendingbubbleshot
                    int temp=a[i];
					a[i]=a[j];//swaping
					a[j]=temp;
					//a[]={0,1,2,4}
					//a[0]=0;
					//a[1]=1;
					//a[2]=2;
					//a[3]=4;
					}
				}
			}
		System.out.println("The Second minimum number is = "+a[1]);//1
}
	}



