
public class Stringbuffer {
	public void M1(String s ) {
		System.out.println("Iam string method");
	}
	public void M1(Stringbuffer sb) {
		System.out.println("im sring buffer method");//nonprimitive
	}
	public class Runner{


	public static void main(String[] args) {
Test t= new Test();
t.M1("Java");
t.M1(new Stringbuffer());
t.M1(null);
String s;
System.out.println(s);//string null,string buffer  null...it will get compliissue
//how to get complietime issue...methodoverloading
 t=null;
	}
	}
}

	

	
