package ArrayImpPrgms;

import java.util.Iterator;

public class ArrayFirstMaxusingDescendingOrder {

	public static void main(String[] args) {
		int arr[]={2,4,56,78,67};
		for (int i = 0; i < arr.length; i++) 
		{
		for (int j = i+1; j < arr.length; j++) 
		{
			if(arr[i]<arr[j]) //lesservalue
			{
				int temp=arr[i];//swap
				arr[i]=arr[j];
				arr[j]=temp;
				
			}
		}	
		}//sorting
		//System.out.println(arr[arr.length-1]);
		//System.out.println(arr[arr.length-2]);
		int sum=0;
		for (int i = 4; i < 5; i++) 
		{
			System.out.println(arr[i]);
			sum=sum+arr[i];
		}
		System.out.println("print first sum max array num"+sum);
	}

}
