package ArrayImpPrgms;

public class FIND1stMaxArrayusingAsscending {

	public static void main(String[] args) {
		int arr[]={1,2,4,5,6,7,8,23,78,34};
		for (int i = 0; i < arr.length; i++) 
		{
			for (int j = i+1; j < arr.length; j++) 
			{
				if(arr[i]>arr[j])//greater
				{
					int temp=arr[i];//swap
					arr[i]=arr[j];
					arr[j]=temp;
				}
			}
		}//sorting
		System.out.println(arr[arr.length-1]);
		//System.out.println(arr[arr.length-2]);
		//System.out.println(arr[arr.length-3]);
	}

}
