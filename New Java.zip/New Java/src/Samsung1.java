
public class Samsung1 {

	public void calling() {
		System.out.println("1pisa/1min");	
	}
	public void camera() {
		System.out.println("2Mp");	
	}

class SamsungGalaxy extends Samsung1{

		public void calling1() {
			System.out.println("45pisa/1min");	
		}
		public void camera() {
			System.out.println("4mp");	
		}
		public void patternlock() {
			System.out.println("iam patternlock");	
		}

class SamsungASeries extends Samsung1{
			public void calling() {
				System.out.println("30pisa/1min");	
			}
			public void camera() {
				System.out.println("8mp");	
			}
			public void games() {
				System.out.println("iam playing games");	
			}
abstract class Samsung{
				public void calling() {
					System.out.println("45/min");	
				}
				public void camera() {
					System.out.println("10mp");	
				}
class SamsaungGalaxy extends Samsung{
					public void calling() {
						System.out.println("30/min");	
					}	
					public void camera() {
						System.out.println("4mp");	
					}
class Samsung1ASeries extends Samsung1{
						public void calling() {
							System.out.println("30/min");	
						}
						public void camera() {
							System.out.println("10mp");	
						}
						public void games() {
							System.out.println("12mp");	
						}}
class SamsungzSeries extends SamsaungGalaxy,Samsung1ASeries {
							public void calling() {
								System.out.println("30/min");	
							}
						}
						
interface calling() {
							public void calling() {
								System.out.println("30/min");	
							}
						}
						
interface Camera() {
			public void camera() {
			System.out.println("30/min");	
								}
							}
interface Frontcamera() {
public void frontcamera() {
System.out.println("2MP");	
		}}
interface patternlock() {
public void patternlock() {
System.out.println("2MP");	
}}
interface Games() {
public void games() {
System.out.println("candycrush");	
}
}

interface Fingerprint() {
public void fringerprint() {
System.out.println("bxnjhx");	
}}
class SamsungzSeries implements calling,camers,patternlock,games{
public void calling() {
System.out.println("80/min");
}}
public void camera() {
System.out.println("6mp");
}
public void patternlock() {
System.out.println("abc");
}
public void games() {
	System.out.println("candy1");
}
public void frontcamera() {
	System.out.println("2mp");
}
class SamsungGen1 implements calling,camera,fingerprint,games,frontcamera(){
	public void calling() {
		System.out.println("7/min");
	}
	public void camera() {
		System.out.println("13mp");
	}
	public void games() {
		System.out.println("candy2");
	}
	public void fringerprint() {
		System.out.println("xxxx");
	}
	public void fronrcamera() {
		System.out.println("5mp");
	}
}										
									

								
							
						
					
				


			
		



