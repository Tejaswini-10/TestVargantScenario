import java.util.ArrayList;
import java.util.HashSet;

//10.Occurance of unique character in a given string 
public class Occuranceofuniquechar {

	public static void main(String[] args) {
		String s="India";//i=2,n=1,d=1,a=1
		ArrayList<Character> al=new ArrayList<Character>();
		for(int i=0;i<s.length();i++) {
			al.add(s.charAt(i));
		}
		for(Character ch: al) {    //
			int count=0;
			for(int i=0;i<s.length();i++) {
				if(ch.equals(s.charAt(i))) {
					count++;
				}
			}
			if(count==1)
			System.out.print(ch);			
		}

	}

}
