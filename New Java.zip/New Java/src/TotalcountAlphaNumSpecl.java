
public class TotalcountAlphaNumSpecl {

	public static void main(String[] args) {
		
		String s="ji@a2#v3$a";
		int AlphaCount=0;
		int  NumberCount=0;
		int specialcharCount=0;

		for(int i=0;i<s.length();i++) {
			char ch= s.charAt(i);
			if(ch>='A'&& ch<='z'||ch>='a'&& ch<='z') {
				AlphaCount++;
			}
			else if(ch>='0'&&ch<='9'){
				NumberCount++;
			}
			else {
				specialcharCount++;
			}
		}
		System.out.println("Alhabets in given string are: "+ AlphaCount);
		System.out.println("Numbers in given string are: "+  NumberCount);
		System.out.println("Specialchar in given string are: "+	specialcharCount);

	}

}


