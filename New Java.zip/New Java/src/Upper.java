
public abstract  class Upper {

	String s="java";
	
	public Upper(String s) {
		this.s()
	}
public abstract void m1() {
	}
	
}
