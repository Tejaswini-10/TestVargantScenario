//RunTime Poly
public class A {
	public static  void M1() {
		System.out.println("iam  from A");
	}
	//WebDriver driver=new ChromeDriver();
	class B extends A{
		public void M1() {
			System.out.println("iam  from B");
		}
	}
	class Runner{
		public static void main(String[] args) {
			A a=new A();
			a.M1();
			B b=new B();
			b.M1();
			A.M1();
			A a=new B();//Binding
			a.M1();
		}
	}


}
