package group8;

public class AddEvenFIbIndex {
	public static void main(String[] args) {
		int n=11;
		

	}

}
