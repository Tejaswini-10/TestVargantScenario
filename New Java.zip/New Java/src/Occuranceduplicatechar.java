import java.util.HashSet;

//9.occarance of duplicate character in a given string

public class Occuranceduplicatechar {

	public static void main(String[] args) {
		String s="Teju";
		HashSet<Character> hs=new HashSet<Character>();
		for(int i=0;i<s.length();i++) {
			hs.add(s.charAt(i));
		}
		for(Character ch: hs) {    //ujeT
			int count=1;
			for(int i=1;i<s.length();i++) {
				if(ch.equals(s.charAt(i))) {
					count++;
				}
			}
		}
	}
}
