package ARMstorndNum;

import java.util.Scanner;

public class ArmStorgNumber {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n=sc.nextInt();
		
//int n=153;
int sum=0;sum=n;
while(n!=0)
{
	int d=n%10;
	sum=sum+d*d*d;
	n=n/10;
}

if(sum==num)
{
	System.out.println(num+ " is an arm strong num");
}
else
{
	System.out.println(num+ " is not an arm strong num");
}
	
	}

}
