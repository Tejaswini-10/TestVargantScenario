//8.Occurance character in a given string
import java.util.HashSet;

public class Occurancecount8 {

	public static void main(String[] args) {
		String s="india";//i=2,n=1,d=1,a=1
		HashSet<Character> hs=new HashSet<Character>();
		for(int i=0;i<s.length();i++) {
			hs.add(s.charAt(i));
		}
		for(Character ch: hs) {    //i,d,a,n
			int count=0;
			for(int i=0;i<s.length();i++) {
				if(ch.equals(s.charAt(i))) {
					count++;
				}
			}
			System.out.println(ch+":"+count);			
		}
	}

}
