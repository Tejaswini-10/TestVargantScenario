package group_4;

public class FindElementWithMaxLengthInArray {

	public static void main(String[] args) {
		
	String[] str = {"helloworld","hello","bye","hi","java","worldhello"};//helloworld worldhello
	String max = str[0];
	
	for(int i=1;i<str.length;i++)
	{                    //str.lrngth=6
		
		if(str[i].length()>max.length())
		{  // use > least length
			max=str[i];
		}
		
	}//System.out.println(maxLenElement);
for (int i = 0; i <str.length; i++) {
	if(str[i].length()==max.length()){
		System.out.println(str[i]);
	
	}
}
	}

}
