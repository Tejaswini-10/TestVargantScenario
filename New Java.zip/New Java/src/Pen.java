
public class Pen {
	private String colour;
	private int price;
	private String brand;
	 

	public Pen(String coour,String brand ,int price) {
	this.colour=coour;
	this.brand=brand;
	this.price=price;
	}
		public static void main(String[] args) {
		}
		@Override
		public String toString() {
		
			return colour+"----"+brand+"-----"+price;
		}

//	String Colour;
//	int Price=300;
//	String Brand="Cello";
//
//	public void writting(){
//
//		System.out.println("iam writting with pen");
//	}
//
//	public static void main(String[] args) {
//		Pen p=new Pen();
//		System.out.println(p.Colour);
//		System.out.println(p.Price);
//		System.out.println(p.Brand);
//
//	}
}


