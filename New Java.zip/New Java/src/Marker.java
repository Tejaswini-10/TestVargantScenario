
public class Marker {

		String Colour;
		int Price;
		String Brand;

		public void writting(){

			System.out.println("iam writting with pen");
		}

		public static void main(String[] args) {
			Pen p=new Pen();
			System.out.println(p.Colour);//p.  hashcode....p.Colour..null
			System.out.println(p.Price);
			System.out.println(p.Brand);

		}
	
	}


