
public class Withoutconstructor {
	 private String colour;
	 private int price;
	 private String brand;
	 
	 private String svg="levies";
	 private int kyt= 2000;
	 
	public static void main(String[] args) {
		
		WithOutConstroctor woc = new WithOutConstroctor();
		
		System.out.println( woc.colour);
		System.out.println( woc.price);
		System.out.println( woc.brand);
		
		System.out.println("--------------");
		
		System.out.println(woc.svg);
		System.out.println(woc.kyt);
	}

	

}
