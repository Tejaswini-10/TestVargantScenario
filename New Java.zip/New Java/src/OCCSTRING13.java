import java.util.ArrayList;
import java.util.LinkedHashSet;

//13.Input:"abcdacbddabc o/p=aaa,bbb,ccc,ddd combination of similar character
public class OCCSTRING13 {

	public static void main(String[] args) {
		String s="abcdacbddabc";//o/p=aaa,bbb,ccc,ddd

		LinkedHashSet<Character> Lh = new LinkedHashSet<Character>();
		
		for(int i=0;i< s.length();i++) {
			Lh.add(s.charAt(i));
		}
		
		for(Character ch: Lh) {    //
			int count=0;
			for(int i=0;i< s.length();i++) {
				if(ch.equals(s.charAt(i))) {
					System.out.print(ch);
				}
			}
			System.out.print(" ");			
		}


	}

}
