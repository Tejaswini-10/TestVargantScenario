//Take a given string and segregate Alphabets,Numbers,special,Specialcharacters
//output java,123,@#$S
public class Givenalphastrnumspechar 
{

	public static void main(String[] args) 
	{

		String s="j1@a2#v3$a";
		String Alpha="";
		String Number="";
		String specialchar="";
		for(int i=0;i<s.length();i++)
		{
			char ch=s.charAt(i);
			if(ch>='A'&& ch<='z'||ch>='a'&& ch<='z') 
			{
				Alpha=Alpha+ch;
			}
			else if(ch>='0'&&ch<='9')
			{
				Number=Number+ch;
			}
			else 
			{
				specialchar=specialchar+ch;
			}
		}
		System.out.println("Alhabets in given string are: "+Alpha);
		System.out.println("Numbers in given string are: "+Number);
		System.out.println("Specialchar in given string are: "+specialchar);

	}


}


