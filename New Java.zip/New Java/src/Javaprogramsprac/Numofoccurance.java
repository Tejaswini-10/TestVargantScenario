package Javaprogramsprac;

import java.util.HashSet;

public class Numofoccurance {

	public static void main(String[] args) {
int[] a= {1,2,3,3,4,4,5,6,7};
HashSet<Integer>hs=new HashSet<Integer>();
for(int i=0;i<a.length;i++)
{
hs.add(i);
}
for(int i:hs)
{
	
}

	}

}
