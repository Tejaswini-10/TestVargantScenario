package Arrayprgms;

public class SecondlargestnumUsingArray {

	public static void main(String[] args) {
		int[] a= {66,86,21,44,56,101,73};
		int temp;
		for(int i=0; i<a.length; i++ ) {
			for(int j=i+1; j<a.length; j++) {
				if(a[i]<a[j]) {
					temp=a[i];
					a[i]=a[j];
					a[j]=temp;
				}
			}
		
		//System.out.println("largest element is"+a[1]);
		}
		System.out.println("second largest element is "+a[2]);
	}

}
