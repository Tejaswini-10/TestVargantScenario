//Reverse a  given string using 2nd variableas well as donot use lengthfunction or varible 
public class lengthfunctiondonotuse {

	public static void main(String[] args) {
String s="Liger";
char[] str=s.toCharArray();
int count=0;
for(char c:str) {
	count++;
	System.out.println(count);
	String rev="";
	for(int i=count-1;i>=0;i--) {
		rev=s.charAt(i)+rev;
		System.out.println(rev);
	}
}
	
	}
}
