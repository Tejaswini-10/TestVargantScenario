
public class Reverseevennumusingforloop {

	public static void main(String[] args) {
		for(int i=10;i>=0;i--) {
			if(i%2==0) {
			System.out.println(i);
			}
	}
	}
}
