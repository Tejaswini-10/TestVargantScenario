
public class Test1 {
	public  void m1(String s) {
		System.out.println("i am String method ");
	}
	
//	public void m1(Object o) {
//		System.out.println("i am object");
//		}
	  
		System.out.println("i am string buffer");
	}
	public void m1()
	{
		
	}
	public static void main(String[] args) {
Test  t = new Test();
///t.m1("");
t.m1("java");
t.m1(new String());
t.m1(null);



	

}
}
