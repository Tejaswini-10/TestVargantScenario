//16.Take a given string and i/p="j1@a2#v3$a" and get sum of numbers present in string
public class Sumofnumberspresentinstring {

	public static void main(String[] args) {

	}

}
