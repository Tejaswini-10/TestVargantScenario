//Reverse a given string

import java.util.Iterator;


public class Reverseastring {

	public static void main(String[] args) {
String s="Program";
int len=s.length();
System.out.println(s.charAt(len));

	for(int i=0;i<s.length();i++) {
		System.out.println(s.charAt(i));
	}
System.out.println("\n");
for(int i=s.length()-1;i>0;i--) {
	System.out.println(s.charAt(i));
}
}
}