
public class Mother {
	
public void Money() {
	
}
public void Gold() {
	
}

	public static void main(String[] args) {

	}

}
