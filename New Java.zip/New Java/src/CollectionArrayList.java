import java.util.ArrayList;

public class CollectionArrayList{
	public static void main(String[] args) {
ArrayList<String>al=new ArrayList<String>();
		al.add("inda");
		al.add("3333");
		al.add("99");
		al.add("rose");
		System.out.println(al);
		al.remove(1);
		al.removeAll(al);
		al.containsAll(al);
		al.add("bbbb");
	}
}