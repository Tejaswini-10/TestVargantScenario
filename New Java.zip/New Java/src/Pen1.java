
public class Pen1 {
	String Colour;
	int Price;
	String Brand;
	public Pen1(String Colour,String brand, int price) {
		this.Colour=Colour;
		this.Price=Price;
		this.Brand=Brand;
	}
class Driver{
	public static void main(String[] args) {
Pen1 p1=new Pen1("Blue","Perker",234);
System.out.println(p1);
	}

}
}
