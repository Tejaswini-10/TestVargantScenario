
public class Pen_2 {
	public static void main(String[] args) {
		Pen p =new Pen("blue",  "parker",  500);
		 
	System.out.println(p);


		}
}
