
public class PositionofCharinString {

	public static void main(String[] args) {
		String s ="Tejaswini chaya";
		   //LinkedHashSet<Character> set = new LinkedHashSet<Character>();
				char[] ch = s.toCharArray();
				System.out.println(ch);
				for(int i=0; i<s.length(); i++)
				{
					//char ch = s.charAt(i);
					//System.out.println(ch +" position "+(i+1));
					//System.out.println(i+1);
					 System.out.println(ch[i]+" position "+(i+1));
			
				//System.out.println(i+1);

					
				}
	}

}
