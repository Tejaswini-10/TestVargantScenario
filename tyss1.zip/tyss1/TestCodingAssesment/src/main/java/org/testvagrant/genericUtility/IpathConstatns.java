package org.testvagrant.genericUtility;

public interface IpathConstatns {
	/**
	 * This interface contains all constant variable for application
	 * @author Tejaswini
	 */
	public String PROPERTYFILEPATH="./src/test/resources/Common_Properties";

}
