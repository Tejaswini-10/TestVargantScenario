package org.testvagrant.genericUtility;

import org.openqa.selenium.WebDriver;

public class InstanceClass {
	public WebDriver driver;
	public JavaUtility javaUtility; 
	public FileUtility fileUtility;
	public WebdriverUtility webdriverUtility;
	public String url; 
	public String url1;
	public String timeouts;
	public String browser;
	public Long longTimeout;
	public int randomnumber;

}
