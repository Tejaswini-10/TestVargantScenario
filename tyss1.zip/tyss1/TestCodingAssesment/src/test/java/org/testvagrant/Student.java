package org.testvagrant;

public class Student {
	public static void main(String[] args) {
		String name = "sai";
		int rollnum = 2;
		int age = 5;
		int marks = 24;
		
	public  void Student( String string1,int rollnum1,int age1,int marks1) {
		this.name="sai";
		this.rollnum=2;
		this.age=5;
		this.marks=24;
	}

}

	private static void Student(String string, int rollnum, int age, int marks) {
		// TODO Auto-generated method stub
		
	}
}
